import React, { useState } from 'react';
import {
  Building2,
  ShieldCheck,
  User,
  Users,
  KeyRound,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Lock,
  Sparkles,
  Info,
  BadgeCheck,
  ChevronRight
} from 'lucide-react';
import { UserAccount, UserRole, ServiceSeksi } from '../types';
import { ROLES_CONFIG, SEKSI_METADATA } from '../data/initialData';

interface LoginFormProps {
  users: UserAccount[];
  onLogin: (user: UserAccount) => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ users, onLogin }) => {
  // Tabs: 'ADMIN' (L1) or 'USER' (L2 - L6)
  const [activeTab, setActiveTab] = useState<'ADMIN' | 'USER'>('ADMIN');
  const [inputNip, setInputNip] = useState('');
  const [selectedSeksiFilter, setSelectedSeksiFilter] = useState<ServiceSeksi | 'ALL'>('ALL');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showQuickAccess, setShowQuickAccess] = useState(false);

  // Filter users for User / Operator Seksi tab
  const regularUsers = users.filter((u) => u.role !== 'L1');

  const displayedQuickUsers = regularUsers.filter(
    (u) => selectedSeksiFilter === 'ALL' || u.seksi === selectedSeksiFilter
  );

  const cleanNip = (val: string) => val.replace(/[\s.-]/g, '').trim();

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const targetNip = cleanNip(inputNip);

    if (!targetNip) {
      setErrorMessage('Silakan masukkan Kode Akses NIP Anda.');
      return;
    }

    // Search user by cleaned NIP or username
    const matchedUser = users.find(
      (u) => cleanNip(u.nip) === targetNip || u.username.toLowerCase() === targetNip.toLowerCase()
    );

    if (!matchedUser) {
      setErrorMessage(
        `Kode Akses NIP "${inputNip}" tidak terdaftar dalam pangkalan data kepegawaian Kecamatan Sukatani.`
      );
      return;
    }

    if (!matchedUser.isActive) {
      setErrorMessage(
        `Akun pegawai atas nama ${matchedUser.fullName} (NIP: ${matchedUser.nip}) berstatus NON-AKTIF. Hubungi Administrator PATEN.`
      );
      return;
    }

    // Tab role compatibility check
    if (activeTab === 'ADMIN' && matchedUser.role !== 'L1') {
      setErrorMessage(
        `NIP terdaftar atas nama ${matchedUser.fullName} (${ROLES_CONFIG[matchedUser.role].shortName}). Akun ini adalah User Seksi, silakan pilih tab "Login User / Operator".`
      );
      return;
    }

    if (activeTab === 'USER' && matchedUser.role === 'L1') {
      setErrorMessage(
        `NIP terdaftar sebagai Administrator Utama (${matchedUser.fullName}). Silakan gunakan tab "Login Admin" untuk akses penuh.`
      );
      return;
    }

    // Success login
    onLogin(matchedUser);
  };

  const handleQuickLogin = (u: UserAccount) => {
    setInputNip(u.nip);
    setErrorMessage(null);
    onLogin(u);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between relative overflow-hidden font-sans">
      {/* Background Decorative Pattern */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-emerald-600/30 blur-3xl" />
        <div className="absolute top-1/2 -right-40 w-96 h-96 rounded-full bg-teal-600/20 blur-3xl" />
        <div className="absolute -bottom-40 left-1/3 w-96 h-96 rounded-full bg-sky-600/20 blur-3xl" />
        <div
          className="w-full h-full"
          style={{
            backgroundImage:
              'radial-gradient(rgba(255, 255, 255, 0.08) 1px, transparent 1px)',
            backgroundSize: '24px 24px',
          }}
        />
      </div>

      {/* Top Bar Branding */}
      <header className="relative z-10 border-b border-slate-800/80 bg-slate-950/60 backdrop-blur-md px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white font-bold shadow-md shadow-emerald-950/60">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 tracking-wider">
                  PATEN
                </span>
                <span className="text-[11px] text-slate-400 font-medium">Satu Pintu</span>
              </div>
              <h1 className="text-sm font-bold text-white tracking-tight">
                Pemerintah Kecamatan Sukatani
              </h1>
              <p className="text-[10px] text-slate-400">Kabupaten Bekasi, Jawa Barat</p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400 bg-slate-800/60 border border-slate-700/60 px-3 py-1.5 rounded-lg">
            <BadgeCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Autentikasi Kedinasan Berbasis NIP ASN</span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 py-8 sm:py-12">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Form Card */}
          <div className="lg:col-span-7 bg-white text-slate-900 rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            {/* Header Form */}
            <div className="p-6 pb-5 bg-gradient-to-b from-slate-50 to-white border-b border-slate-100">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Portal Kepegawaian PATEN
                </span>
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <Lock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Akses Terenkripsi</span>
                </div>
              </div>

              <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
                Masuk Sistem Pelayanan
              </h2>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Silakan pilih kategori pengguna dan masukkan Kode Akses NIP (Nomor Induk Pegawai) Anda.
              </p>

              {/* Role Tabs */}
              <div className="grid grid-cols-2 gap-2 mt-5 p-1 bg-slate-100 rounded-xl border border-slate-200">
                <button
                  type="button"
                  id="tab-login-admin"
                  onClick={() => {
                    setActiveTab('ADMIN');
                    setErrorMessage(null);
                  }}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs font-bold transition-all ${
                    activeTab === 'ADMIN'
                      ? 'bg-white text-emerald-800 shadow-sm border border-slate-200/80'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                  }`}
                >
                  <ShieldCheck className={`w-4 h-4 ${activeTab === 'ADMIN' ? 'text-emerald-600' : 'text-slate-400'}`} />
                  <span>Login Admin (L1)</span>
                </button>

                <button
                  type="button"
                  id="tab-login-user"
                  onClick={() => {
                    setActiveTab('USER');
                    setErrorMessage(null);
                  }}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs font-bold transition-all ${
                    activeTab === 'USER'
                      ? 'bg-white text-emerald-800 shadow-sm border border-slate-200/80'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                  }`}
                >
                  <Users className={`w-4 h-4 ${activeTab === 'USER' ? 'text-emerald-600' : 'text-slate-400'}`} />
                  <span>Login User / Operator</span>
                </button>
              </div>
            </div>

            {/* Form Body */}
            <div className="p-6">
              {/* Context Banner */}
              <div
                className={`mb-5 p-3 rounded-xl border text-xs flex items-start gap-2.5 ${
                  activeTab === 'ADMIN'
                    ? 'bg-emerald-50/70 border-emerald-200/80 text-emerald-900'
                    : 'bg-sky-50/70 border-sky-200/80 text-sky-900'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-md flex items-center justify-center shrink-0 mt-0.5 ${
                    activeTab === 'ADMIN' ? 'bg-emerald-600 text-white' : 'bg-sky-600 text-white'
                  }`}
                >
                  {activeTab === 'ADMIN' ? (
                    <ShieldCheck className="w-3.5 h-3.5" />
                  ) : (
                    <User className="w-3.5 h-3.5" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-bold">
                    {activeTab === 'ADMIN'
                      ? 'Akses Administrator Sistem & Koordinator PATEN'
                      : 'Akses Petugas & Operator Seksi Pelayanan'}
                  </p>
                  <p className="text-[11px] opacity-90 mt-0.5">
                    {activeTab === 'ADMIN'
                      ? 'Memiliki hak kelola Master Data (User, Desa, Layanan), rekapitulasi seluruh seksi, dan otoritas penuh.'
                      : 'Memiliki hak input pelayanan dan analitik sesuai seksi penugasan (Yanlik, Pem, Ekbang, PMD, Trantib).'}
                  </p>
                </div>
              </div>

              {/* Error Alert */}
              {errorMessage && (
                <div
                  id="login-error-alert"
                  className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5 animate-in fade-in"
                >
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div className="flex-1 font-medium leading-relaxed">{errorMessage}</div>
                </div>
              )}

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                {/* Input Kode Akses NIP */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label
                      htmlFor="input-nip-field"
                      className="block text-xs font-bold text-slate-700 uppercase tracking-wider"
                    >
                      Kode Akses NIP Pegawai
                    </label>
                    <span className="text-[11px] text-slate-400 font-normal">18 Digit NIP Resmi</span>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <KeyRound className="w-4 h-4" />
                    </div>
                    <input
                      id="input-nip-field"
                      type="text"
                      value={inputNip}
                      onChange={(e) => {
                        setInputNip(e.target.value);
                        if (errorMessage) setErrorMessage(null);
                      }}
                      placeholder={
                        activeTab === 'ADMIN'
                          ? 'Masukkan 18 digit NIP Administrator'
                          : 'Masukkan 18 digit NIP (Contoh: 198804122010012004)'
                      }
                      className="w-full pl-10 pr-4 py-3 bg-slate-50 hover:bg-white focus:bg-white border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 rounded-xl text-sm font-mono text-slate-900 tracking-wider transition-all placeholder:text-slate-400 placeholder:font-sans placeholder:tracking-normal"
                      autoFocus
                    />
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1.5 flex items-center gap-1">
                    <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>Format NIP dapat berupa 18 digit angka bersambung atau dipisah spasi.</span>
                  </p>
                </div>

                {/* Optional filter if tab is USER */}
                {activeTab === 'USER' && (
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Pilihan Seksi Penugasan (Filter NIP)
                    </label>
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                      <button
                        type="button"
                        onClick={() => setSelectedSeksiFilter('ALL')}
                        className={`py-1.5 px-2 rounded-lg text-[11px] font-semibold transition-all ${
                          selectedSeksiFilter === 'ALL'
                            ? 'bg-slate-800 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        Semua
                      </button>
                      {(['YANLIK', 'PEMERINTAHAN', 'EKBANG', 'PMD', 'TRANTIB'] as ServiceSeksi[]).map(
                        (seksiKey) => {
                          const meta = SEKSI_METADATA[seksiKey];
                          const isActive = selectedSeksiFilter === seksiKey;
                          return (
                            <button
                              key={seksiKey}
                              type="button"
                              onClick={() => setSelectedSeksiFilter(seksiKey)}
                              className={`py-1.5 px-2 rounded-lg text-[11px] font-semibold transition-all truncate ${
                                isActive
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              }`}
                            >
                              {meta.short}
                            </button>
                          );
                        }
                      )}
                    </div>
                  </div>
                )}

                {/* Submit Action */}
                <div className="pt-2">
                  <button
                    type="submit"
                    id="btn-submit-login"
                    className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-sm rounded-xl shadow-md shadow-emerald-700/25 transition-all cursor-pointer"
                  >
                    <span>Masuk ke Sistem PATEN</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            </div>

            {/* Bottom Card Footer */}
            <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Sistem Terintegrasi Online
              </span>
              <span className="font-mono text-[11px] text-slate-400">Versi 2.4.0</span>
            </div>
          </div>

          {/* Right Column: Quick Access / NIP Reference Directory */}
          <div className="lg:col-span-5 space-y-4">
            {activeTab === 'ADMIN' ? (
              /* Admin Security & Authorization Card (Box Daftar NIP Resmi dihapus pada login Admin) */
              <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-5 shadow-xl backdrop-blur-sm space-y-4">
                <div className="flex items-center gap-2.5 border-b border-slate-700/80 pb-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                      Prosedur Masuk Admin (L1)
                    </h3>
                    <p className="text-[10px] text-slate-400">Otoritas Koordinator & Admin Sistem PATEN</p>
                  </div>
                </div>

                <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
                  <p className="text-[11px] text-slate-300">
                    Demi menjaga integritas sistem dan keamanan data pelayanan publik di lingkungan Kecamatan Sukatani:
                  </p>
                  <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-700/80 text-[11px] space-y-2.5">
                    <div className="flex items-start gap-2.5">
                      <Lock className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <p className="text-slate-300">
                        <strong className="text-white">NIP Dirahasiakan:</strong> Kotak daftar NIP resmi ditiadakan pada portal Administrator untuk mencegah upaya akses tanpa hak.
                      </p>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <BadgeCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <p className="text-slate-300">
                        <strong className="text-white">Input Mandiri Pegawai:</strong> Administrator diwajibkan mengetikkan 18 digit NIP resmi yang telah diotorisasi secara mandiri.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* User Security & Authorization Card */
              <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-5 shadow-xl backdrop-blur-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-700/80 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400">
                      <Users className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                        Prosedur Masuk Petugas Seksi (L2–L6)
                      </h3>
                      <p className="text-[10px] text-slate-400">Operator Loket & Pelaksana Teknis PATEN</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowQuickAccess(!showQuickAccess)}
                    className="text-[10px] font-medium text-slate-300 hover:text-white bg-slate-700/60 hover:bg-slate-700 px-2.5 py-1 rounded-lg border border-slate-600 transition-colors flex items-center gap-1 cursor-pointer"
                    title={showQuickAccess ? 'Sembunyikan Referensi NIP' : 'Tampilkan Referensi NIP'}
                  >
                    <span>{showQuickAccess ? 'Sembunyikan NIP' : 'Referensi NIP'}</span>
                  </button>
                </div>

                <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
                  <p className="text-[11px] text-slate-300">
                    Prosedur masuk bagi staf dan operator seksi di lingkungan Kantor Kecamatan Sukatani:
                  </p>
                  <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-700/80 text-[11px] space-y-2.5">
                    <div className="flex items-start gap-2.5">
                      <Lock className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                      <p className="text-slate-300">
                        <strong className="text-white">NIP Dirahasiakan:</strong> Daftar NIP disembunyikan untuk menjaga kerahasiaan identitas dan akun kedinasan ASN/Non-ASN.
                      </p>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <BadgeCheck className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                      <p className="text-slate-300">
                        <strong className="text-white">Input Mandiri Pegawai:</strong> Silakan ketik 18 digit NIP resmi Anda pada kolom isian di sebelah kiri sesuai penugasan seksi masing-masing.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Collapsible Quick Access Directory (Hidden by default) */}
                {showQuickAccess && (
                  <div className="pt-3 border-t border-slate-700/80 space-y-3 animate-in fade-in">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-sky-400" />
                        <h4 className="text-[11px] font-bold text-white uppercase tracking-wider">
                          Daftar Kode Akses NIP Resmi
                        </h4>
                      </div>
                      <span className="text-[10px] bg-sky-500/20 text-sky-300 border border-sky-500/30 px-2 py-0.5 rounded-full font-medium">
                        Operator Seksi
                      </span>
                    </div>

                    <p className="text-[10px] text-slate-400 leading-relaxed">
                      Pilih akun operator seksi di bawah ini untuk mengisi NIP dan masuk ke dalam sistem:
                    </p>

                    <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                      {displayedQuickUsers.map((usr) => {
                        const seksiMeta = usr.seksi ? SEKSI_METADATA[usr.seksi] : null;

                        return (
                          <div
                            key={usr.id}
                            className="p-3 bg-slate-900/90 hover:bg-slate-900 border border-slate-700/80 hover:border-sky-500/50 rounded-xl transition-all group flex flex-col gap-2"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700 font-mono">
                                    {usr.role}
                                  </span>
                                  {seksiMeta && (
                                    <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-sky-500/10 text-sky-300 border border-sky-500/20">
                                      {seksiMeta.short}
                                    </span>
                                  )}
                                  <span className="text-xs font-bold text-white group-hover:text-sky-300 transition-colors truncate">
                                    {usr.fullName}
                                  </span>
                                </div>
                                <p className="text-[11px] text-slate-400 mt-0.5">{usr.jabatan}</p>
                              </div>
                            </div>

                            <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                              <div className="text-[11px] font-mono text-slate-300">
                                <span className="text-slate-400 mr-1">NIP:</span>
                                <span className="font-semibold text-sky-400">{usr.nip}</span>
                              </div>

                              <button
                                type="button"
                                onClick={() => handleQuickLogin(usr)}
                                className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded-lg transition-colors shadow-2xs cursor-pointer"
                              >
                                <span>Gunakan NIP</span>
                                <ChevronRight className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Help Card */}
            <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-3.5 text-xs text-slate-400 space-y-1.5">
              <p className="font-bold text-slate-300 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-emerald-400" />
                Catatan Hak Akses ASN:
              </p>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-400 leading-relaxed">
                <li>
                  <strong className="text-slate-300">Admin (L1):</strong> Membuka seluruh menu administrasi dan rekapitulasi 18 jenis pelayanan.
                </li>
                <li>
                  <strong className="text-slate-300">User Seksi (L2–L6):</strong> Membatasi menu input dan data hanya pada seksi masing-masing sesuai SK Camat Sukatani.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-slate-800/80 bg-slate-950/60 py-4 px-6 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>
            © 2026 Kantor Kecamatan Sukatani - Kabupaten Bekasi. Seluruh hak cipta dilindungi undang-undang.
          </p>
          <p className="text-[11px] text-slate-400">
            Sistem Informasi Pelayanan Administrasi Terpadu Kecamatan (PATEN)
          </p>
        </div>
      </footer>
    </div>
  );
};
