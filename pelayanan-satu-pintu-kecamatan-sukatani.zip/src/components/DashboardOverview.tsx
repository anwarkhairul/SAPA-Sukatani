import React from 'react';
import {
  FilePlus,
  CheckCircle2,
  Clock,
  AlertCircle,
  TrendingUp,
  Building,
  Users,
  Printer,
  Eye,
  ArrowRight,
  ShieldCheck,
  Calendar,
  Sparkles
} from 'lucide-react';
import { Desa, ServiceDefinition, ServiceRecord, UserAccount } from '../types';
import { ROLES_CONFIG, SEKSI_METADATA } from '../data/initialData';
import { formatDateIndonesian } from '../utils/numberGenerator';
import { ServiceIcon } from './ServiceIcon';

interface DashboardOverviewProps {
  currentUser: UserAccount;
  records: ServiceRecord[];
  services: ServiceDefinition[];
  desasList: Desa[];
  onOpenNewServiceModal: (preselectedServiceId?: string) => void;
  onOpenDetail: (record: ServiceRecord) => void;
  onOpenPrint: (record: ServiceRecord) => void;
  onNavigateView: (view: string) => void;
  onOpenInfoMatrix: () => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  currentUser,
  records,
  services,
  desasList,
  onOpenNewServiceModal,
  onOpenDetail,
  onOpenPrint,
  onNavigateView,
  onOpenInfoMatrix,
}) => {
  const isL1 = currentUser.role === 'L1';
  const roleConfig = ROLES_CONFIG[currentUser.role];
  const allowedSeksi = roleConfig.allowedSeksi;

  // Filter records within role scope
  const visibleRecords = records.filter((r) => isL1 || r.seksi === currentUser.seksi);
  const total = visibleRecords.length;
  const selesai = visibleRecords.filter((r) => r.status === 'SELESAI').length;
  const proses = visibleRecords.filter((r) => r.status === 'DIPROSES' || r.status === 'DIVERIFIKASI').length;
  const draft = visibleRecords.filter((r) => r.status === 'DRAFT').length;

  // Filter services that can be entered by this role
  const availableServices = services.filter((s) => allowedSeksi.includes(s.seksi));

  const recentRecords = [...visibleRecords].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5);

  const getStatusBadge = (st: string) => {
    switch (st) {
      case 'SELESAI':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'DIPROSES':
        return 'bg-sky-50 text-sky-700 border-sky-200';
      case 'DIVERIFIKASI':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'DITOLAK':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-amber-50 text-amber-700 border-amber-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 p-6 text-white shadow-md border border-slate-700/60">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-semibold tracking-wide">
                PATEN KECAMATAN SUKATANI
              </span>
              <span className="text-xs text-slate-400">Kabupaten Bekasi</span>
            </div>
            <h1 className="text-xl md:text-2xl font-extrabold tracking-tight text-white">
              Selamat Bertugas, {currentUser.fullName}
            </h1>
            <p className="text-xs text-slate-300 leading-relaxed">
              Anda masuk dengan hak akses <strong>{roleConfig.name}</strong>. Sistem siap melayani input berkas permohonan warga, verifikasi dokumen, penomoran resmi registrasi, dan pencetakan resi pelayanan satu pintu.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenInfoMatrix}
              className="flex items-center gap-1.5 px-3 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-semibold backdrop-blur-xs transition-colors border border-white/10"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Lihat Matriks Hak Akses</span>
            </button>
            <button
              onClick={() => onOpenNewServiceModal()}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-lg text-xs shadow-lg shadow-emerald-500/30 transition-all"
            >
              <FilePlus className="w-4 h-4" />
              <span>Input Pelayanan Baru</span>
            </button>
          </div>
        </div>

        {/* Decorative subtle ambient light */}
        <div className="absolute right-0 top-0 -mt-8 -mr-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Pelayanan</span>
            <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2">{total}</div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            {isL1 ? 'Seluruh seksi terdata' : `Seksi ${SEKSI_METADATA[currentUser.seksi!]?.short}`}
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-700">Pelayanan Selesai</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-emerald-700 mt-2">{selesai}</div>
          <p className="text-[11px] text-emerald-600 mt-0.5">Dokumen siap diambil warga</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-sky-700">Sedang Diproses</span>
            <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-sky-700 mt-2">{proses}</div>
          <p className="text-[11px] text-sky-600 mt-0.5">Dalam tindak lanjut & verifikasi</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-700">Draft / Syarat Kurang</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-amber-700 mt-2">{draft}</div>
          <p className="text-[11px] text-amber-600 mt-0.5">Menunggu kelengkapan pemohon</p>
        </div>
      </div>

      {/* Quick Service Action Launcher */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Layanan Cepat (Dapat Diinput oleh {currentUser.role})
            </h3>
            <p className="text-[11px] text-slate-500">
              Klik pada salah satu layanan untuk langsung membuka formulir registrasi nomor resmi:
            </p>
          </div>
          <span className="text-[11px] font-semibold text-slate-500">
            {availableServices.length} Layanan Tersedia
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {availableServices.map((srv) => {
            const seksiMeta = SEKSI_METADATA[srv.seksi];
            return (
              <button
                key={srv.id}
                onClick={() => onOpenNewServiceModal(srv.id)}
                className="text-left p-3 rounded-lg border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/40 transition-all flex items-start gap-3 group"
              >
                <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors shrink-0 mt-0.5">
                  <ServiceIcon iconName={srv.iconName} className="w-4 h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-[10px] text-slate-400 font-semibold">{srv.kode}</span>
                    <span className={`text-[9px] px-1 py-0.2 rounded font-medium border ${seksiMeta.badgeBg} ${seksiMeta.badgeBorder}`}>
                      {seksiMeta.short}
                    </span>
                  </div>
                  <h4 className="font-bold text-xs text-slate-900 group-hover:text-emerald-800 transition-colors line-clamp-1">
                    {srv.nama}
                  </h4>
                  <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5 font-mono">
                    {srv.formatKode}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent Records Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Permohonan Pelayanan Terbaru Masuk
            </h3>
            <p className="text-[11px] text-slate-500">
              Daftar 5 permohonan terkini yang telah dicatat di sistem loket PATEN.
            </p>
          </div>
          <button
            onClick={() => onNavigateView('pelayanan-list')}
            className="flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800"
          >
            <span>Lihat Semua Data</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">No. Registrasi</th>
                <th className="py-3 px-3">Tanggal Masuk</th>
                <th className="py-3 px-4">Jenis Pelayanan</th>
                <th className="py-3 px-4">Pemohon</th>
                <th className="py-3 px-3">Desa</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {recentRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    Belum ada riwayat permohonan pelayanan.
                  </td>
                </tr>
              ) : (
                recentRecords.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono font-bold text-emerald-800 text-[11px]">
                      {r.noRegistrasi}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      {formatDateIndonesian(r.tanggalPengajuan)}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {r.serviceNama}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold uppercase text-slate-900">{r.citizen.namaLengkap}</div>
                      <div className="text-[10px] text-slate-400 font-mono">NIK: {r.citizen.nik}</div>
                    </td>
                    <td className="py-3 px-3">
                      Desa {r.citizen.desa}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadge(r.status)}`}>
                        {r.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onOpenDetail(r)}
                          className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md transition-colors"
                          title="Lihat Detail"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onOpenPrint(r)}
                          className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-md transition-colors"
                          title="Cetak Resi Tanda Terima"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
