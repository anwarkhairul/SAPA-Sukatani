import React, { useState } from 'react';
import {
  Search,
  PlusCircle,
  UserCheck,
  ChevronDown,
  Calendar,
  Check,
  SlidersHorizontal,
  Info,
  LogOut
} from 'lucide-react';
import { INITIAL_USERS, ROLES_CONFIG, SEKSI_METADATA } from '../data/initialData';
import { UserAccount, UserRole } from '../types';

interface HeaderProps {
  currentUser: UserAccount;
  onSwitchUser: (user: UserAccount) => void;
  onOpenNewServiceModal: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenInfoModal: () => void;
  onLogout?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onSwitchUser,
  onOpenNewServiceModal,
  searchQuery,
  setSearchQuery,
  onOpenInfoModal,
  onLogout,
}) => {
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  const todayStr = new Intl.DateTimeFormat('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  const currentRoleInfo = ROLES_CONFIG[currentUser.role];

  return (
    <header
      id="main-header"
      className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between sticky top-0 z-20 shadow-xs"
    >
      {/* Search Input */}
      <div className="flex items-center gap-4 flex-1 max-w-md">
        <div className="relative w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="global-search-input"
            type="text"
            placeholder="Cari No. Registrasi, NIK, atau Nama Pemohon..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs px-1"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-3">
        {/* Date Display */}
        <div className="hidden lg:flex items-center gap-1.5 text-xs text-slate-500 bg-slate-50 border border-slate-200/80 px-2.5 py-1.5 rounded-md">
          <Calendar className="w-3.5 h-3.5 text-emerald-600" />
          <span>{todayStr}</span>
        </div>

        {/* Info / Hak Akses Matrix popup button */}
        <button
          id="btn-info-matrix"
          onClick={onOpenInfoModal}
          title="Lihat Matriks Hak Akses"
          className="p-1.5 text-slate-500 hover:text-slate-700 bg-slate-50 border border-slate-200 rounded-md hover:bg-slate-100 transition-colors"
        >
          <Info className="w-4 h-4" />
        </button>

        {/* Fast Role / User Switcher */}
        <div className="relative">
          <button
            id="btn-switch-role"
            onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs text-slate-700 font-medium transition-all shadow-2xs"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span className="font-semibold text-slate-900">{currentUser.role}</span>
            <span className="hidden sm:inline text-slate-600 max-w-[140px] truncate">
              {currentRoleInfo.shortName}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-0.5" />
          </button>

          {roleDropdownOpen && (
            <>
              <div
                className="fixed inset-0 z-30"
                onClick={() => setRoleDropdownOpen(false)}
              />
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-40 animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3.5 py-2 border-b border-slate-100">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-bold text-slate-900">Ganti Level Hak Akses</p>
                    <span className="text-[10px] font-medium bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded border border-emerald-200">
                      Simulasi User
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Pilih level operator untuk menguji pembatasan menu dan data pelayanan sesuai dokumen rancangan.
                  </p>
                </div>

                <div className="p-1 space-y-0.5 max-h-96 overflow-y-auto">
                  {INITIAL_USERS.map((usr) => {
                    const isSelected = usr.id === currentUser.id;
                    const rConfig = ROLES_CONFIG[usr.role];
                    const seksiMeta = usr.seksi ? SEKSI_METADATA[usr.seksi] : null;

                    return (
                      <button
                        key={usr.id}
                        onClick={() => {
                          onSwitchUser(usr);
                          setRoleDropdownOpen(false);
                        }}
                        className={`w-full text-left p-2 rounded-lg text-xs transition-colors flex items-start gap-2.5 ${
                          isSelected
                            ? 'bg-emerald-50 border border-emerald-200/80 text-emerald-950'
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <div
                          className={`w-7 h-7 rounded-md font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 ${
                            isSelected
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-100 text-slate-700 border border-slate-200'
                          }`}
                        >
                          {usr.role}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-semibold text-slate-900 truncate">
                              {rConfig.shortName}
                            </p>
                            {isSelected && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                          </div>
                          <p className="text-[11px] text-slate-500 truncate">{usr.fullName}</p>
                          <p className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">
                            {rConfig.description}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {onLogout && (
                  <div className="p-1.5 border-t border-slate-100 bg-slate-50/50">
                    <button
                      type="button"
                      id="btn-logout-from-dropdown"
                      onClick={() => {
                        setRoleDropdownOpen(false);
                        onLogout();
                      }}
                      className="w-full flex items-center justify-center gap-2 py-1.5 px-3 rounded-lg text-xs font-semibold text-rose-600 hover:bg-rose-50 hover:text-rose-700 transition-colors"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Keluar ke Form Login NIP</span>
                    </button>
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {/* Logout Quick Button */}
        {onLogout && (
          <button
            id="btn-header-logout"
            onClick={onLogout}
            title="Keluar dari Sistem (Kunci Sesi)"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-rose-50 hover:border-rose-200 hover:text-rose-600 text-xs text-slate-600 font-medium transition-all shadow-2xs"
          >
            <LogOut className="w-3.5 h-3.5 text-slate-400 group-hover:text-rose-600" />
            <span className="hidden md:inline">Keluar</span>
          </button>
        )}

        {/* Primary Action Button: Input Data Pelayanan */}
        <button
          id="btn-input-pelayanan-header"
          onClick={onOpenNewServiceModal}
          className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-semibold px-3.5 py-2 rounded-lg shadow-sm shadow-emerald-700/20 transition-all"
        >
          <PlusCircle className="w-4 h-4" />
          <span className="hidden sm:inline">Input Data Pelayanan</span>
          <span className="sm:hidden">Input</span>
        </button>
      </div>
    </header>
  );
};
