import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  Shield,
  Search
} from 'lucide-react';
import { UserAccount, UserRole, ServiceSeksi } from '../types';
import { ROLES_CONFIG, SEKSI_METADATA } from '../data/initialData';

interface KelolaUserViewProps {
  users: UserAccount[];
  onAddUser: (user: UserAccount) => void;
  onUpdateUser: (user: UserAccount) => void;
  onDeleteUser: (userId: string) => void;
}

export const KelolaUserView: React.FC<KelolaUserViewProps> = ({
  users,
  onAddUser,
  onUpdateUser,
  onDeleteUser,
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [search, setSearch] = useState('');

  // Form states
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [nip, setNip] = useState('');
  const [role, setRole] = useState<UserRole>('L2');
  const [seksi, setSeksi] = useState<ServiceSeksi | ''>('YANLIK');
  const [email, setEmail] = useState('');
  const [jabatan, setJabatan] = useState('');
  const [isActive, setIsActive] = useState(true);

  const openAddModal = () => {
    setEditingUser(null);
    setFullName('');
    setUsername('');
    setNip('');
    setRole('L2');
    setSeksi('YANLIK');
    setEmail('');
    setJabatan('Staf Pelayanan');
    setIsActive(true);
    setModalOpen(true);
  };

  const openEditModal = (u: UserAccount) => {
    setEditingUser(u);
    setFullName(u.fullName);
    setUsername(u.username);
    setNip(u.nip);
    setRole(u.role);
    setSeksi(u.seksi || '');
    setEmail(u.email);
    setJabatan(u.jabatan);
    setIsActive(u.isActive);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !username) return;

    if (editingUser) {
      onUpdateUser({
        ...editingUser,
        fullName,
        username,
        nip,
        role,
        seksi: role === 'L1' ? undefined : (seksi as ServiceSeksi),
        email,
        jabatan,
        isActive,
      });
    } else {
      const newUser: UserAccount = {
        id: `usr-${Date.now()}`,
        fullName,
        username,
        nip,
        role,
        seksi: role === 'L1' ? undefined : (seksi as ServiceSeksi),
        email,
        jabatan,
        isActive,
      };
      onAddUser(newUser);
    }
    setModalOpen(false);
  };

  const filteredUsers = users.filter((u) => {
    const q = search.toLowerCase();
    return (
      u.fullName.toLowerCase().includes(q) ||
      u.username.toLowerCase().includes(q) ||
      u.nip.includes(q)
    );
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-600" />
            <span>Kelola Pengguna & Hak Akses (Level 1 - 6)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manajemen akun operator loket PATEN dan pembagian level hak akses seksi di Kecamatan Sukatani.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
        >
          <UserPlus className="w-4 h-4" />
          <span>Tambah Pengguna Baru</span>
        </button>
      </div>

      {/* Search and stats */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
        <div className="relative w-72">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari nama, username, NIP..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
          />
        </div>
        <span className="text-xs text-slate-500">
          Total Terdaftar: <strong>{users.length}</strong> Akun
        </span>
      </div>

      {/* User Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Nama Lengkap & NIP</th>
                <th className="py-3 px-3">Username & Email</th>
                <th className="py-3 px-3">Level Hak Akses</th>
                <th className="py-3 px-3">Penugasan Seksi</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredUsers.map((u) => {
                const rConfig = ROLES_CONFIG[u.role];
                const seksiMeta = u.seksi ? SEKSI_METADATA[u.seksi] : null;

                return (
                  <tr key={u.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{u.fullName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">NIP: {u.nip || '-'}</div>
                      <div className="text-[10px] text-slate-500">{u.jabatan}</div>
                    </td>

                    <td className="py-3 px-3">
                      <div className="font-medium text-slate-800 font-mono text-[11px]">{u.username}</div>
                      <div className="text-[10px] text-slate-400">{u.email}</div>
                    </td>

                    <td className="py-3 px-3">
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md font-bold text-xs bg-slate-100 text-slate-800 border border-slate-200">
                        <Shield className="w-3 h-3 text-emerald-600" />
                        {u.role} - {rConfig.shortName}
                      </span>
                    </td>

                    <td className="py-3 px-3">
                      {u.role === 'L1' ? (
                        <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          Akses Semua Seksi (Full)
                        </span>
                      ) : seksiMeta ? (
                        <span className={`text-[10px] px-2 py-0.5 rounded font-medium border ${seksiMeta.badgeBg} ${seksiMeta.badgeBorder}`}>
                          {seksiMeta.name}
                        </span>
                      ) : (
                        '-'
                      )}
                    </td>

                    <td className="py-3 px-3 text-center">
                      {u.isActive ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3" />
                          Aktif
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200">
                          <XCircle className="w-3 h-3" />
                          Nonaktif
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openEditModal(u)}
                          className="p-1.5 hover:bg-slate-100 text-slate-600 rounded-md transition-colors"
                          title="Edit Pengguna"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {users.length > 1 && (
                          <button
                            onClick={() => {
                              if (confirm(`Hapus pengguna ${u.fullName}?`)) {
                                onDeleteUser(u.id);
                              }
                            }}
                            className="p-1.5 hover:bg-rose-50 text-rose-600 rounded-md transition-colors"
                            title="Hapus Pengguna"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                {editingUser ? 'Edit Data Pengguna' : 'Tambah Pengguna Baru'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Nama Lengkap & Gelar *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Contoh: Siti Rahmawati, S.AP"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Username Login *</label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="nama.user"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">NIP Pegawai</label>
                  <input
                    type="text"
                    value={nip}
                    onChange={(e) => setNip(e.target.value)}
                    placeholder="19880412..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Level Hak Akses *</label>
                  <select
                    value={role}
                    onChange={(e) => {
                      const newRole = e.target.value as UserRole;
                      setRole(newRole);
                      if (newRole === 'L2') setSeksi('YANLIK');
                      else if (newRole === 'L3') setSeksi('PEMERINTAHAN');
                      else if (newRole === 'L4') setSeksi('EKBANG');
                      else if (newRole === 'L5') setSeksi('PMD');
                      else if (newRole === 'L6') setSeksi('TRANTIB');
                      else setSeksi('');
                    }}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-semibold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="L1">Level 1: Administrator (Full)</option>
                    <option value="L2">Level 2: Seksi Yanlik</option>
                    <option value="L3">Level 3: Seksi Pemerintahan</option>
                    <option value="L4">Level 4: Seksi Ekbang</option>
                    <option value="L5">Level 5: Seksi PMD</option>
                    <option value="L6">Level 6: Seksi Trantib</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Jabatan / Posisi</label>
                  <input
                    type="text"
                    value={jabatan}
                    onChange={(e) => setJabatan(e.target.value)}
                    placeholder="Staf Seksi..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Email Dinas</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="operator@sukatani.bekasikab.go.id"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                  />
                  <span className="text-slate-800 font-medium">Akun Aktif (Dapat login dan input berkas)</span>
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-100 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Pengguna
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
