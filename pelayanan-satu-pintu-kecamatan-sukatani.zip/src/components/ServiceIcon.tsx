import React from 'react';
import {
  FileText,
  HeartHandshake,
  Baby,
  Hospital,
  ShieldPlus,
  GraduationCap,
  Users,
  Stamp,
  Landmark,
  FileSpreadsheet,
  Split,
  Building2,
  Home,
  RadioTower,
  FileCheck,
  MapPin,
  School,
  Volume2,
  FileBadge,
  Shield,
  Flag,
  HelpCircle
} from 'lucide-react';

interface ServiceIconProps {
  iconName: string;
  className?: string;
}

export const ServiceIcon: React.FC<ServiceIconProps> = ({ iconName, className = 'w-5 h-5' }) => {
  switch (iconName) {
    case 'HeartHandshake': return <HeartHandshake className={className} />;
    case 'Baby': return <Baby className={className} />;
    case 'Hospital': return <Hospital className={className} />;
    case 'ShieldPlus': return <ShieldPlus className={className} />;
    case 'GraduationCap': return <GraduationCap className={className} />;
    case 'FileText': return <FileText className={className} />;
    case 'Users': return <Users className={className} />;
    case 'Stamp': return <Stamp className={className} />;
    case 'Landmark': return <Landmark className={className} />;
    case 'FileSpreadsheet': return <FileSpreadsheet className={className} />;
    case 'Split': return <Split className={className} />;
    case 'Building2': return <Building2 className={className} />;
    case 'Home': return <Home className={className} />;
    case 'RadioTower': return <RadioTower className={className} />;
    case 'FileCheck': return <FileCheck className={className} />;
    case 'MapPin': return <MapPin className={className} />;
    case 'School': return <School className={className} />;
    case 'Volume2': return <Volume2 className={className} />;
    case 'FileBadge': return <FileBadge className={className} />;
    case 'Shield': return <Shield className={className} />;
    case 'Flag': return <Flag className={className} />;
    default: return <HelpCircle className={className} />;
  }
};
