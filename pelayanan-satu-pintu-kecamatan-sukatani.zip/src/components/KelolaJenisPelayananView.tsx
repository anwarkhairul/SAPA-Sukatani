import React, { useState } from 'react';
import {
  Settings,
  Plus,
  Edit2,
  Trash2,
  Search,
  CheckCircle2,
  Info,
  Layers,
  Sparkles,
  FileCode
} from 'lucide-react';
import { ServiceDefinition, ServiceSeksi } from '../types';
import { SEKSI_METADATA } from '../data/initialData';
import { ServiceIcon } from './ServiceIcon';

interface KelolaJenisPelayananViewProps {
  services: ServiceDefinition[];
  onAddService: (service: ServiceDefinition) => void;
  onUpdateService: (service: ServiceDefinition) => void;
  onDeleteService: (serviceId: string) => void;
}

export const KelolaJenisPelayananView: React.FC<KelolaJenisPelayananViewProps> = ({
  services,
  onAddService,
  onUpdateService,
  onDeleteService,
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<ServiceDefinition | null>(null);
  const [seksiFilter, setSeksiFilter] = useState<string>('ALL');
  const [search, setSearch] = useState('');

  // Form states
  const [nama, setNama] = useState('');
  const [kode, setKode] = useState('');
  const [formatKode, setFormatKode] = useState('{KODE}/{URUT}/{BULAN}/{TAHUN}');
  const [seksi, setSeksi] = useState<ServiceSeksi>('YANLIK');
  const [deskripsi, setDeskripsi] = useState('');
  const [syaratStr, setSyaratStr] = useState('');

  const openAdd = () => {
    setEditingService(null);
    setNama('');
    setKode('');
    setFormatKode('{KODE}/{URUT}/{BULAN}/{TAHUN}');
    setSeksi('YANLIK');
    setDeskripsi('');
    setSyaratStr('Surat Pengantar RT/RW dan Kepala Desa\nFotokopi KTP & KK Pemohon');
    setModalOpen(true);
  };

  const openEdit = (s: ServiceDefinition) => {
    setEditingService(s);
    setNama(s.nama);
    setKode(s.kode);
    setFormatKode(s.formatKode);
    setSeksi(s.seksi);
    setDeskripsi(s.deskripsi);
    setSyaratStr(s.syaratDokumen.join('\n'));
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nama.trim() || !kode.trim()) return;

    const syaratList = syaratStr
      .split('\n')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    if (editingService) {
      onUpdateService({
        ...editingService,
        nama,
        kode,
        formatKode,
        seksi,
        deskripsi,
        syaratDokumen: syaratList,
      });
    } else {
      const newService: ServiceDefinition = {
        id: `srv-${seksi.toLowerCase()}-${Date.now()}`,
        nama,
        kode,
        formatKode,
        seksi,
        deskripsi,
        iconName: 'FileText',
        syaratDokumen: syaratList,
      };
      onAddService(newService);
    }
    setModalOpen(false);
  };

  const filtered = services.filter((s) => {
    const matchSeksi = seksiFilter === 'ALL' || s.seksi === seksiFilter;
    const matchSearch =
      s.nama.toLowerCase().includes(search.toLowerCase()) ||
      s.kode.toLowerCase().includes(search.toLowerCase()) ||
      s.formatKode.toLowerCase().includes(search.toLowerCase());
    return matchSeksi && matchSearch;
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Settings className="w-5 h-5 text-emerald-600" />
            <span>Tabel Referensi Jenis Pelayanan & Format Kode</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Konfigurasi kode pelayanan resmi, format penomoran registrasi otomatis, dan dokumen persyaratan.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Jenis Pelayanan</span>
        </button>
      </div>

      {/* Official SKTM Banner Callout as specified in PDF */}
      <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white p-4 rounded-xl shadow-xs border border-emerald-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
              Format Kode Resmi Registrasi SKTM Kecamatan Sukatani:
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-1 text-[11px]">
            <div className="bg-white/10 px-2.5 py-1.5 rounded-lg border border-white/10">
              <span className="text-emerald-300 font-semibold block">SKTM Jamkesda:</span>
              <code className="font-mono text-white text-[10px]">400.7.3.1/Nomor Urut/Bulan/Tahun</code>
            </div>
            <div className="bg-white/10 px-2.5 py-1.5 rounded-lg border border-white/10">
              <span className="text-emerald-300 font-semibold block">SKTM KIS:</span>
              <code className="font-mono text-white text-[10px]">400.7.3.6/Nomor Urut/Bulan/Tahun</code>
            </div>
            <div className="bg-white/10 px-2.5 py-1.5 rounded-lg border border-white/10">
              <span className="text-emerald-300 font-semibold block">SKTM KIP:</span>
              <code className="font-mono text-white text-[10px]">400.7.3.7/Nomor Urut/Bulan/Tahun</code>
            </div>
            <div className="bg-white/10 px-2.5 py-1.5 rounded-lg border border-white/10">
              <span className="text-emerald-300 font-semibold block">SKTM Lainnya:</span>
              <code className="font-mono text-white text-[10px]">400.7.3.2/Nomor Urut/Bulan/Tahun</code>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <select
            value={seksiFilter}
            onChange={(e) => setSeksiFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-800 font-medium focus:ring-2 focus:ring-emerald-500"
          >
            <option value="ALL">Semua Seksi Pelayanan</option>
            <option value="YANLIK">Seksi Yanlik</option>
            <option value="PEMERINTAHAN">Seksi Pemerintahan</option>
            <option value="EKBANG">Seksi Ekbang</option>
            <option value="PMD">Seksi PMD</option>
            <option value="TRANTIB">Seksi Trantib</option>
          </select>

          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari kode atau nama layanan..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        <span className="text-slate-500">
          Total: <strong>{filtered.length}</strong> Jenis Pelayanan Terdaftar
        </span>
      </div>

      {/* Reference Table: Kode, Jenis Pelayanan, Format Kode, Aksi (Tambah, Edit, Hapus) */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4 w-24">Kode</th>
                <th className="py-3 px-4">Jenis Pelayanan</th>
                <th className="py-3 px-3">Seksi Bidang</th>
                <th className="py-3 px-4">Format Kode Resmi Registrasi</th>
                <th className="py-3 px-3 text-center">Jml Syarat</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filtered.map((srv) => {
                const seksiMeta = SEKSI_METADATA[srv.seksi];

                return (
                  <tr key={srv.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4">
                      <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                        {srv.kode}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                          <ServiceIcon iconName={srv.iconName} className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="font-bold text-slate-900">{srv.nama}</div>
                          <div className="text-[10px] text-slate-400 line-clamp-1">{srv.deskripsi}</div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`text-[10px] px-2 py-0.5 rounded-md font-semibold border ${seksiMeta.badgeBg} ${seksiMeta.badgeBorder}`}>
                        {seksiMeta.short}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <code className="font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[11px]">
                        {srv.formatKode}
                      </code>
                    </td>

                    <td className="py-3 px-3 text-center">
                      <span className="text-slate-600 font-semibold">
                        {srv.syaratDokumen?.length || 0} Berkas
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openEdit(srv)}
                          className="p-1.5 hover:bg-slate-100 text-slate-600 rounded-md transition-colors"
                          title="Edit Layanan & Format Kode"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {services.length > 1 && (
                          <button
                            onClick={() => {
                              if (confirm(`Hapus jenis pelayanan "${srv.nama}"?`)) {
                                onDeleteService(srv.id);
                              }
                            }}
                            className="p-1.5 hover:bg-rose-50 text-rose-600 rounded-md transition-colors"
                            title="Hapus Layanan"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto border border-slate-200">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between sticky top-0 z-10">
              <h3 className="text-sm font-bold text-slate-900">
                {editingService ? 'Edit Jenis Pelayanan' : 'Tambah Jenis Pelayanan Baru'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-3.5 text-xs">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Kode *</label>
                  <input
                    type="text"
                    required
                    value={kode}
                    onChange={(e) => setKode(e.target.value)}
                    placeholder="Contoh: 400.7.3.1"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1">Seksi Penanggung Jawab *</label>
                  <select
                    value={seksi}
                    onChange={(e) => setSeksi(e.target.value as ServiceSeksi)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 font-medium"
                  >
                    <option value="YANLIK">Seksi Pelayanan Publik (Yanlik)</option>
                    <option value="PEMERINTAHAN">Seksi Pemerintahan</option>
                    <option value="EKBANG">Seksi Ekonomi & Pembangunan (Ekbang)</option>
                    <option value="PMD">Seksi Pemberdayaan Masyarakat & Desa (PMD)</option>
                    <option value="TRANTIB">Seksi Ketenteraman & Ketertiban (Trantib)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Nama Jenis Pelayanan *</label>
                <input
                  type="text"
                  required
                  value={nama}
                  onChange={(e) => setNama(e.target.value)}
                  placeholder="Contoh: SKTM Pengantar Jamkesda"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Format Kode Registrasi Otomatis *
                </label>
                <input
                  type="text"
                  required
                  value={formatKode}
                  onChange={(e) => setFormatKode(e.target.value)}
                  placeholder="Contoh: 400.7.3.1/{URUT}/{BULAN}/{TAHUN}"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-emerald-900 bg-emerald-50/50 focus:ring-2 focus:ring-emerald-500"
                />
                <p className="text-[10px] text-slate-500 mt-1">
                  Tag pengganti: <code className="bg-slate-100 px-1 rounded">{'{URUT}'}</code> (nomor urut), <code className="bg-slate-100 px-1 rounded">{'{BULAN}'}</code> (angka bulan), <code className="bg-slate-100 px-1 rounded">{'{BULAN_ROMAWI}'}</code> (bulan romawi), <code className="bg-slate-100 px-1 rounded">{'{TAHUN}'}</code>.
                </p>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Deskripsi Singkat</label>
                <textarea
                  rows={2}
                  value={deskripsi}
                  onChange={(e) => setDeskripsi(e.target.value)}
                  placeholder="Penjelasan fungsi dokumen layanan..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Syarat Dokumen Fisik (1 Baris = 1 Persyaratan)
                </label>
                <textarea
                  rows={4}
                  value={syaratStr}
                  onChange={(e) => setSyaratStr(e.target.value)}
                  placeholder="Surat Pengantar RT/RW dan Kepala Desa&#10;Fotokopi KTP & KK Pemohon"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 text-xs font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-100 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Jenis Pelayanan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
