import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Download,
  Plus,
  Eye,
  Printer,
  Calendar,
  ChevronDown,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileText
} from 'lucide-react';
import { Desa, ServiceRecord, ServiceSeksi, ServiceStatus, UserAccount } from '../types';
import { formatDateIndonesian } from '../utils/numberGenerator';
import { ROLES_CONFIG, SEKSI_METADATA } from '../data/initialData';

interface DataPelayananTableProps {
  currentUser: UserAccount;
  records: ServiceRecord[];
  desasList: Desa[];
  onOpenDetail: (record: ServiceRecord) => void;
  onOpenPrint: (record: ServiceRecord) => void;
  onOpenNewServiceModal: () => void;
  selectedSeksiFilter?: ServiceSeksi | 'ALL';
  setSelectedSeksiFilter?: (seksi: ServiceSeksi | 'ALL') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const DataPelayananTable: React.FC<DataPelayananTableProps> = ({
  currentUser,
  records,
  desasList,
  onOpenDetail,
  onOpenPrint,
  onOpenNewServiceModal,
  selectedSeksiFilter = 'ALL',
  setSelectedSeksiFilter,
  searchQuery,
  setSearchQuery,
}) => {
  const roleConfig = ROLES_CONFIG[currentUser.role];
  const isL1 = currentUser.role === 'L1';

  // Filters
  const [filterDesa, setFilterDesa] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  // Enforce access matrix: if not L1, only records for the user's section can be shown
  const visibleRecords = useMemo(() => {
    return records.filter((rec) => {
      // Role enforcement
      if (!isL1 && rec.seksi !== currentUser.seksi) {
        return false;
      }

      // Seksi filter if L1
      if (isL1 && selectedSeksiFilter !== 'ALL' && rec.seksi !== selectedSeksiFilter) {
        return false;
      }

      // Desa filter
      if (filterDesa !== 'ALL' && rec.citizen.desa !== filterDesa) {
        return false;
      }

      // Status filter
      if (filterStatus !== 'ALL' && rec.status !== filterStatus) {
        return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchReg = rec.noRegistrasi.toLowerCase().includes(q);
        const matchNik = rec.citizen.nik.includes(q);
        const matchNama = rec.citizen.namaLengkap.toLowerCase().includes(q);
        const matchService = rec.serviceNama.toLowerCase().includes(q);
        return matchReg || matchNik || matchNama || matchService;
      }

      return true;
    });
  }, [records, isL1, currentUser.seksi, selectedSeksiFilter, filterDesa, filterStatus, searchQuery]);

  const handleExportCsv = () => {
    const headers = [
      'No Registrasi',
      'Tanggal Pengajuan',
      'Jenis Pelayanan',
      'Seksi',
      'NIK',
      'Nama Pemohon',
      'Desa',
      'RT/RW',
      'No HP',
      'Status',
      'Petugas',
    ];

    const rows = visibleRecords.map((r) => [
      `"${r.noRegistrasi}"`,
      `"${r.tanggalPengajuan}"`,
      `"${r.serviceNama}"`,
      `"${r.seksi}"`,
      `"'${r.citizen.nik}"`,
      `"${r.citizen.namaLengkap}"`,
      `"${r.citizen.desa}"`,
      `"${r.citizen.rtRw}"`,
      `"${r.citizen.noHp}"`,
      `"${r.status}"`,
      `"${r.petugasNama}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `rekap-pelayanan-sukatani-${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadge = (st: ServiceStatus) => {
    switch (st) {
      case 'SELESAI':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'DIPROSES':
        return 'bg-sky-50 text-sky-700 border-sky-200';
      case 'DIVERIFIKASI':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'DITOLAK':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-amber-50 text-amber-700 border-amber-200';
    }
  };

  const currentSeksiMeta = currentUser.seksi ? SEKSI_METADATA[currentUser.seksi] : null;

  return (
    <div className="space-y-4">
      {/* Top Banner & Context Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span>Daftar Data Input Pelayanan</span>
            {!isL1 && currentSeksiMeta && (
              <span className={`text-xs px-2 py-0.5 rounded-md font-semibold border ${currentSeksiMeta.badgeBg} ${currentSeksiMeta.badgeBorder}`}>
                {currentSeksiMeta.short}
              </span>
            )}
            {isL1 && selectedSeksiFilter !== 'ALL' && (
              <span className="text-xs px-2 py-0.5 rounded-md font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                Filter: {selectedSeksiFilter}
              </span>
            )}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {isL1
              ? 'Administrator memiliki akses melihat dan mengelola seluruh seksi pelayanan di Kecamatan Sukatani.'
              : `Akses dibatasi hanya untuk ${roleConfig.name} (${roleConfig.description}).`}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor CSV</span>
          </button>
          <button
            onClick={onOpenNewServiceModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Input Data Baru</span>
          </button>
        </div>
      </div>

      {/* Filter Row */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center gap-3 text-xs">
        <div className="flex items-center gap-1.5 text-slate-500 font-medium">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span>Filter Data:</span>
        </div>

        {/* Seksi Filter (Only for L1 Admin) */}
        {isL1 && setSelectedSeksiFilter && (
          <select
            value={selectedSeksiFilter}
            onChange={(e) => setSelectedSeksiFilter(e.target.value as ServiceSeksi | 'ALL')}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-800 font-medium focus:ring-2 focus:ring-emerald-500"
          >
            <option value="ALL">Semua Seksi Pelayanan</option>
            <option value="YANLIK">Seksi Pelayanan Publik (Yanlik)</option>
            <option value="PEMERINTAHAN">Seksi Pemerintahan</option>
            <option value="EKBANG">Seksi Ekbang</option>
            <option value="PMD">Seksi PMD</option>
            <option value="TRANTIB">Seksi Trantib</option>
          </select>
        )}

        {/* Desa Filter */}
        <select
          value={filterDesa}
          onChange={(e) => setFilterDesa(e.target.value)}
          className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-800 font-medium focus:ring-2 focus:ring-emerald-500"
        >
          <option value="ALL">Semua Desa Wilayah Sukatani</option>
          {desasList.map((d) => (
            <option key={d.id} value={d.nama}>
              Desa {d.nama}
            </option>
          ))}
        </select>

        {/* Status Filter */}
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-800 font-medium focus:ring-2 focus:ring-emerald-500"
        >
          <option value="ALL">Semua Status Permohonan</option>
          <option value="DRAFT">DRAFT</option>
          <option value="DIVERIFIKASI">DIVERIFIKASI</option>
          <option value="DIPROSES">DIPROSES</option>
          <option value="SELESAI">SELESAI</option>
          <option value="DITOLAK">DITOLAK</option>
        </select>

        <div className="ml-auto text-slate-500 text-[11px]">
          Menampilkan <strong>{visibleRecords.length}</strong> data pelayanan
        </div>
      </div>

      {/* Main Records Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200 text-[11px] uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">No. Registrasi</th>
                <th className="py-3 px-3">Tgl & Jam</th>
                <th className="py-3 px-4">Jenis Pelayanan & Seksi</th>
                <th className="py-3 px-4">Data Pemohon</th>
                <th className="py-3 px-3">Desa Wilayah</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {visibleRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <FileText className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-600">Tidak ada data pelayanan ditemukan</p>
                    <p className="text-[11px]">Coba sesuaikan filter pencarian atau buat input baru.</p>
                  </td>
                </tr>
              ) : (
                visibleRecords.map((record) => {
                  const seksiMeta = SEKSI_METADATA[record.seksi];

                  return (
                    <tr key={record.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* Registration Code */}
                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 inline-block text-[11px]">
                          {record.noRegistrasi}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          Petugas: {record.petugasNama}
                        </div>
                      </td>

                      {/* Date & Time */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <div className="font-medium text-slate-900">
                          {formatDateIndonesian(record.tanggalPengajuan)}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {record.waktuPengajuan} WIB
                        </div>
                      </td>

                      {/* Service & Seksi */}
                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-semibold text-slate-900 leading-tight">
                          {record.serviceNama}
                        </div>
                        <span className={`inline-block text-[10px] mt-1 px-1.5 py-0.2 rounded font-medium border ${seksiMeta.badgeBg} ${seksiMeta.badgeBorder}`}>
                          {seksiMeta.name}
                        </span>
                      </td>

                      {/* Citizen */}
                      <td className="py-3 px-4">
                        <div className="font-bold uppercase text-slate-900">
                          {record.citizen.namaLengkap}
                        </div>
                        <div className="font-mono text-[10px] text-slate-500">
                          NIK: {record.citizen.nik}
                        </div>
                        <div className="text-[10px] text-emerald-700">
                          {record.citizen.noHp}
                        </div>
                      </td>

                      {/* Desa */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className="font-medium text-slate-800">Desa {record.citizen.desa}</span>
                        <div className="text-[10px] text-slate-400">RT/RW: {record.citizen.rtRw}</div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadge(record.status)}`}>
                          {record.status}
                        </span>
                      </td>

                      {/* Action buttons */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onOpenDetail(record)}
                            title="Lihat Detail & Proses"
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onOpenPrint(record)}
                            title="Cetak Resi Tanda Terima"
                            className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-md transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
