import React from 'react';
import { X, Check, CheckCircle, ShieldCheck } from 'lucide-react';

interface HakAksesMatrixModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HakAksesMatrixModal: React.FC<HakAksesMatrixModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Matriks Hak Akses Menu Aplikasi PATEN Kecamatan Sukatani
              </h3>
              <p className="text-xs text-slate-500">
                Sesuai dengan dokumen rancangan struktur menu 6 Level User
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Table */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">Menu / Jenis Pelayanan</th>
                  <th className="py-3 px-3 text-center bg-slate-200/60 font-bold">Admin (L1)</th>
                  <th className="py-3 px-3 text-center">Yanlik (L2)</th>
                  <th className="py-3 px-3 text-center">Pemerintahan (L3)</th>
                  <th className="py-3 px-3 text-center">Ekbang (L4)</th>
                  <th className="py-3 px-3 text-center">PMD (L5)</th>
                  <th className="py-3 px-3 text-center">Trantib (L6)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                <tr>
                  <td className="py-3 px-4 font-medium">
                    Manajemen User & System
                    <div className="text-[10px] text-slate-500 font-normal">Kelola User, Data Master Desa, Format Kode Pelayanan</div>
                  </td>
                  <td className="py-3 px-3 text-center bg-emerald-50 text-emerald-600 font-bold text-sm">✔</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-medium">
                    Layanan Yanlik
                    <div className="text-[10px] text-slate-500 font-normal">SKTM (Jamkesda, KIS, KIP, Lainnya), Belum Menikah, Belum Punya Anak</div>
                  </td>
                  <td className="py-3 px-3 text-center bg-emerald-50 text-emerald-600 font-bold text-sm">✔</td>
                  <td className="py-3 px-3 text-center bg-sky-50 text-sky-600 font-bold text-sm">✔</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-medium">
                    Layanan Pemerintahan
                    <div className="text-[10px] text-slate-500 font-normal">Pernyataan Ahli Waris, Legalisasi Ahli Waris WNI, AJB Tanah, AJB Waris, APHB</div>
                  </td>
                  <td className="py-3 px-3 text-center bg-emerald-50 text-emerald-600 font-bold text-sm">✔</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center bg-emerald-50 text-emerald-600 font-bold text-sm">✔</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-medium">
                    Layanan Ekbang
                    <div className="text-[10px] text-slate-500 font-normal">Rekomendasi PBG, Rekomendasi IMB Perumahan, Rekomendasi Bangunan Tower</div>
                  </td>
                  <td className="py-3 px-3 text-center bg-emerald-50 text-emerald-600 font-bold text-sm">✔</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center bg-amber-50 text-amber-600 font-bold text-sm">✔</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-medium">
                    Layanan PMD
                    <div className="text-[10px] text-slate-500 font-normal">Proposal Hibah, Keterangan Domisili Haji, Pendirian Lembaga Pendidikan (PAUD s/d SMK)</div>
                  </td>
                  <td className="py-3 px-3 text-center bg-emerald-50 text-emerald-600 font-bold text-sm">✔</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center bg-purple-50 text-purple-600 font-bold text-sm">✔</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-medium">
                    Layanan Trantib
                    <div className="text-[10px] text-slate-500 font-normal">Surat Izin Keramaian, SKCK, Pendaftaran TNI/POLRI, Pemasangan Spanduk</div>
                  </td>
                  <td className="py-3 px-3 text-center bg-emerald-50 text-emerald-600 font-bold text-sm">✔</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center text-slate-400">✖</td>
                  <td className="py-3 px-3 text-center bg-rose-50 text-rose-600 font-bold text-sm">✔</td>
                </tr>
                <tr className="bg-slate-50/70 font-semibold">
                  <td className="py-3 px-4">
                    Rekapitulasi & Grafik Pelayanan
                    <div className="text-[10px] text-slate-500 font-normal">Cakupan laporan analitik dan statistik data</div>
                  </td>
                  <td className="py-3 px-3 text-center text-emerald-700 bg-emerald-100/70 font-bold">Semuanya</td>
                  <td className="py-3 px-3 text-center text-sky-700">Seksi L2</td>
                  <td className="py-3 px-3 text-center text-emerald-700">Seksi L3</td>
                  <td className="py-3 px-3 text-center text-amber-700">Seksi L4</td>
                  <td className="py-3 px-3 text-center text-purple-700">Seksi L5</td>
                  <td className="py-3 px-3 text-center text-rose-700">Seksi L6</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
            <p className="font-semibold text-slate-800">Format Resmi Registrasi SKTM Kecamatan Sukatani:</p>
            <ul className="list-disc pl-4 space-y-0.5 text-slate-600">
              <li><span className="font-medium text-slate-800">SKTM Jamkesda:</span> <code className="bg-white px-1 py-0.5 rounded border border-slate-200 text-emerald-700">400.7.3.1/Nomor Urut/Bulan/Tahun</code></li>
              <li><span className="font-medium text-slate-800">SKTM KIS:</span> <code className="bg-white px-1 py-0.5 rounded border border-slate-200 text-emerald-700">400.7.3.6/Nomor Urut/Bulan/Tahun</code></li>
              <li><span className="font-medium text-slate-800">SKTM KIP:</span> <code className="bg-white px-1 py-0.5 rounded border border-slate-200 text-emerald-700">400.7.3.7/Nomor Urut/Bulan/Tahun</code></li>
              <li><span className="font-medium text-slate-800">SKTM Lainnya:</span> <code className="bg-white px-1 py-0.5 rounded border border-slate-200 text-emerald-700">400.7.3.2/Nomor Urut/Bulan/Tahun</code></li>
            </ul>
          </div>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 text-white rounded-lg text-xs font-semibold hover:bg-slate-700 transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
