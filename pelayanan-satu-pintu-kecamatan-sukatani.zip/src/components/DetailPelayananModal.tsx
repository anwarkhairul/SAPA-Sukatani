import React, { useState } from 'react';
import {
  X,
  FileText,
  Printer,
  CheckCircle2,
  Clock,
  AlertTriangle,
  User,
  MapPin,
  Calendar,
  Building,
  Save,
  Trash2
} from 'lucide-react';
import { ServiceRecord, ServiceStatus, UserAccount } from '../types';
import { formatDateIndonesian } from '../utils/numberGenerator';
import { SEKSI_METADATA } from '../data/initialData';

interface DetailPelayananModalProps {
  record: ServiceRecord | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount;
  onUpdateStatus: (recordId: string, newStatus: ServiceStatus, catatan?: string) => void;
  onDeleteRecord?: (recordId: string) => void;
  onPrintReceipt: (record: ServiceRecord) => void;
}

export const DetailPelayananModal: React.FC<DetailPelayananModalProps> = ({
  record,
  isOpen,
  onClose,
  currentUser,
  onUpdateStatus,
  onDeleteRecord,
  onPrintReceipt,
}) => {
  if (!isOpen || !record) return null;

  const [status, setStatus] = useState<ServiceStatus>(record.status);
  const [catatan, setCatatan] = useState(record.catatanPetugas || '');
  const seksiMeta = SEKSI_METADATA[record.seksi];

  const handleSave = () => {
    onUpdateStatus(record.id, status, catatan);
    onClose();
  };

  const getStatusBadge = (st: ServiceStatus) => {
    switch (st) {
      case 'SELESAI':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'DIPROSES':
        return 'bg-sky-100 text-sky-800 border-sky-300';
      case 'DIVERIFIKASI':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'DITOLAK':
        return 'bg-rose-100 text-rose-800 border-rose-300';
      default:
        return 'bg-amber-100 text-amber-800 border-amber-300';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[92vh] overflow-hidden flex flex-col border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {record.noRegistrasi}
                </span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${getStatusBadge(record.status)}`}>
                  {record.status}
                </span>
              </div>
              <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                {record.serviceNama}
              </h3>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onPrintReceipt(record)}
              className="flex items-center gap-1 px-3 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-300 rounded-lg text-xs font-semibold transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Resi</span>
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200/60"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs">
          {/* Status updater box */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800">Proses & Pembaharuan Status:</span>
              <span className="text-[11px] text-slate-500">
                Oleh: {currentUser.fullName} ({currentUser.role})
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-medium mb-1">Ubah Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as ServiceStatus)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white font-medium focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="DRAFT">DRAFT (Menunggu Kelengkapan)</option>
                  <option value="DIVERIFIKASI">DIVERIFIKASI (Berkas Lengkap)</option>
                  <option value="DIPROSES">DIPROSES (Dalam Tindak Lanjut Seksi)</option>
                  <option value="SELESAI">SELESAI (Dokumen Siap Diambil)</option>
                  <option value="DITOLAK">DITOLAK (Tidak Memenuhi Syarat)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Catatan Verifikasi</label>
                <input
                  type="text"
                  value={catatan}
                  onChange={(e) => setCatatan(e.target.value)}
                  placeholder="Catatan perkembangan berkas..."
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Citizen Details */}
          <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-white">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
              <User className="w-4 h-4 text-emerald-600" />
              <span className="font-bold text-slate-900">Data Pemohon / Kependudukan</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-2.5 gap-x-4 text-slate-700">
              <div>
                <span className="text-slate-400 block text-[10px]">NIK</span>
                <span className="font-mono font-bold text-slate-900">{record.citizen.nik}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">No. Kartu Keluarga</span>
                <span className="font-mono text-slate-900">{record.citizen.noKk || '-'}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Nama Lengkap</span>
                <span className="font-bold uppercase text-slate-900">{record.citizen.namaLengkap}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Tempat, Tgl Lahir</span>
                <span>{record.citizen.tempatLahir}, {formatDateIndonesian(record.citizen.tanggalLahir)}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Jenis Kelamin / Agama</span>
                <span>{record.citizen.jenisKelamin === 'L' ? 'Laki-laki' : 'Perempuan'} / {record.citizen.agama}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Pekerjaan</span>
                <span>{record.citizen.pekerjaan}</span>
              </div>
              <div className="col-span-2">
                <span className="text-slate-400 block text-[10px]">Alamat & Desa</span>
                <span>{record.citizen.alamat}, Desa {record.citizen.desa} (RT/RW: {record.citizen.rtRw})</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">No. Telepon / WA</span>
                <span className="font-medium text-emerald-700">{record.citizen.noHp}</span>
              </div>
            </div>
          </div>

          {/* Service Specific Details */}
          <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-white">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
              <Building className="w-4 h-4 text-emerald-600" />
              <span className="font-bold text-slate-900">Rincian Dokumen & Persyaratan</span>
            </div>

            <div className="space-y-2">
              <div>
                <span className="text-slate-400 block text-[10px]">Seksi Penanggung Jawab</span>
                <span className="font-semibold text-slate-800">{seksiMeta.name}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Keperluan Pemohon</span>
                <span className="text-slate-800 italic">{record.keperluan || '-'}</span>
              </div>

              {record.detailKhusus && Object.keys(record.detailKhusus).length > 0 && (
                <div className="p-3 bg-slate-50 rounded-lg space-y-1 mt-2">
                  <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wider block">
                    Data Isian Spesifik:
                  </span>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    {Object.entries(record.detailKhusus).map(([k, v]) => (
                      <div key={k}>
                        <span className="text-slate-500 capitalize">{k.replace(/([A-Z])/g, ' $1')}: </span>
                        <span className="font-medium text-slate-800">
                          {typeof v === 'number' && k.toLowerCase().includes('nilai')
                            ? `Rp ${v.toLocaleString('id-ID')}`
                            : String(v)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2 pt-1">
                <div>
                  <span className="text-slate-400 block text-[10px]">Petugas Penerima</span>
                  <span className="font-medium text-slate-800">{record.petugasNama}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Tanggal & Jam Masuk</span>
                  <span className="text-slate-800">
                    {formatDateIndonesian(record.tanggalPengajuan)} ({record.waktuPengajuan} WIB)
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div>
            {onDeleteRecord && (currentUser.role === 'L1') && (
              <button
                type="button"
                onClick={() => {
                  if (confirm('Apakah Anda yakin ingin menghapus data pelayanan ini?')) {
                    onDeleteRecord(record.id);
                    onClose();
                  }
                }}
                className="flex items-center gap-1 text-rose-600 hover:text-rose-800 text-xs font-semibold"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus Data</span>
              </button>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-lg text-xs font-semibold"
            >
              Tutup
            </button>
            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Simpan Perubahan</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
