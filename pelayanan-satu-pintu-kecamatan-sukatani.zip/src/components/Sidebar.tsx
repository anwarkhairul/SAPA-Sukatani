import React from 'react';
import {
  LayoutDashboard,
  Users,
  MapPin,
  Settings,
  FilePlus,
  BarChart3,
  PieChart,
  ShieldCheck,
  ChevronRight,
  FolderOpen,
  CheckCircle2,
  Building,
  HardHat,
  HeartHandshake,
  ShieldAlert,
  ChevronDown,
  LogOut
} from 'lucide-react';
import { ROLES_CONFIG, SEKSI_METADATA } from '../data/initialData';
import { ServiceSeksi, UserAccount, UserRole } from '../types';

interface SidebarProps {
  currentUser: UserAccount;
  activeView: string;
  setActiveView: (view: string) => void;
  selectedSeksiFilter?: ServiceSeksi | 'ALL';
  setSelectedSeksiFilter?: (seksi: ServiceSeksi | 'ALL') => void;
  onOpenNewServiceModal?: (preselectedServiceId?: string) => void;
  onLogout?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentUser,
  activeView,
  setActiveView,
  selectedSeksiFilter = 'ALL',
  setSelectedSeksiFilter,
  onOpenNewServiceModal,
  onLogout,
}) => {
  const roleConfig = ROLES_CONFIG[currentUser.role];
  const isL1 = currentUser.role === 'L1';
  const isL2 = currentUser.role === 'L2';
  const isL3 = currentUser.role === 'L3';
  const isL4 = currentUser.role === 'L4';
  const isL5 = currentUser.role === 'L5';
  const isL6 = currentUser.role === 'L6';

  const [inputMenuOpen, setInputMenuOpen] = React.useState(true);
  const [laporanMenuOpen, setLaporanMenuOpen] = React.useState(true);
  const [masterMenuOpen, setMasterMenuOpen] = React.useState(true);

  return (
    <aside
      id="sidebar-container"
      className="w-72 bg-slate-900 text-slate-300 flex flex-col h-screen border-r border-slate-800 shrink-0 select-none"
    >
      {/* Brand Header */}
      <div id="sidebar-header" className="p-4 border-b border-slate-800/80 bg-slate-950/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white font-bold shadow-md shadow-emerald-950/40 shrink-0">
            <Building className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 tracking-wide">
                PATEN
              </span>
              <span className="text-[11px] text-slate-400 uppercase tracking-wider font-medium">Satu Pintu</span>
            </div>
            <h1 className="text-sm font-bold text-white tracking-tight truncate">
              Kecamatan Sukatani
            </h1>
            <p className="text-[11px] text-slate-400 truncate">Kabupaten Bekasi</p>
          </div>
        </div>

        {/* Current Active User Profile Card */}
        <div className="mt-3.5 p-2.5 rounded-lg bg-slate-800/80 border border-slate-700/60 flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center border border-slate-600">
            {currentUser.role}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold text-slate-100 truncate">{currentUser.fullName}</p>
            <p className="text-[10px] text-emerald-400 font-medium truncate">{roleConfig.shortName}</p>
          </div>
          <span className="w-2 h-2 rounded-full bg-emerald-400 ring-4 ring-emerald-500/20" title="Online / Aktif"></span>
        </div>
      </div>

      {/* Navigation Links Scrollable */}
      <div id="sidebar-nav-scroll" className="flex-1 overflow-y-auto px-3 py-4 space-y-6 text-xs">
        {/* Main Dashboard */}
        <div>
          <button
            id="nav-dashboard-overview"
            onClick={() => setActiveView('dashboard')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg font-medium transition-all ${
              activeView === 'dashboard'
                ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-900/50'
                : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard Utama</span>
          </button>
        </div>

        {/* Level 1: Master Data & Pengaturan */}
        {isL1 && (
          <div className="space-y-1">
            <button
              onClick={() => setMasterMenuOpen(!masterMenuOpen)}
              className="w-full flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-2 py-1 hover:text-slate-200"
            >
              <span>Master Data & Pengaturan</span>
              {masterMenuOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
            {masterMenuOpen && (
              <div className="space-y-1 pl-1 pt-1">
                <button
                  id="nav-master-user"
                  onClick={() => setActiveView('master-user')}
                  className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md font-medium transition-all ${
                    activeView === 'master-user'
                      ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  <span>Kelola User & Hak Akses</span>
                </button>
                <button
                  id="nav-master-desa"
                  onClick={() => setActiveView('master-desa')}
                  className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md font-medium transition-all ${
                    activeView === 'master-desa'
                      ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>Kelola Data Master (Desa)</span>
                </button>
                <button
                  id="nav-master-layanan"
                  onClick={() => setActiveView('master-layanan')}
                  className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md font-medium transition-all ${
                    activeView === 'master-layanan'
                      ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  <Settings className="w-3.5 h-3.5 text-slate-400" />
                  <span>Tabel Referensi Jenis Layanan</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Input Data Pelayanan (Semua Seksi for L1, or Specific Seksi for L2-L6) */}
        <div className="space-y-1">
          <button
            onClick={() => setInputMenuOpen(!inputMenuOpen)}
            className="w-full flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-2 py-1 hover:text-slate-200"
          >
            <span>Input Data Pelayanan</span>
            {inputMenuOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>
          {inputMenuOpen && (
            <div className="space-y-1 pl-1 pt-1">
              {/* If L1: Show all seksi */}
              {isL1 && (
                <>
                  <button
                    id="nav-pelayanan-all"
                    onClick={() => {
                      if (setSelectedSeksiFilter) setSelectedSeksiFilter('ALL');
                      setActiveView('pelayanan-list');
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list' && selectedSeksiFilter === 'ALL'
                        ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <FolderOpen className="w-3.5 h-3.5 text-slate-400" />
                      <span>Semua Data Pelayanan</span>
                    </div>
                  </button>

                  <button
                    id="nav-seksi-yanlik"
                    onClick={() => {
                      if (setSelectedSeksiFilter) setSelectedSeksiFilter('YANLIK');
                      setActiveView('pelayanan-list');
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list' && selectedSeksiFilter === 'YANLIK'
                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="w-2 h-2 rounded-full bg-sky-400 shrink-0"></span>
                      <span className="truncate">Seksi Pelayanan Publik (Yanlik)</span>
                    </div>
                  </button>

                  <button
                    id="nav-seksi-pem"
                    onClick={() => {
                      if (setSelectedSeksiFilter) setSelectedSeksiFilter('PEMERINTAHAN');
                      setActiveView('pelayanan-list');
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list' && selectedSeksiFilter === 'PEMERINTAHAN'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0"></span>
                      <span className="truncate">Seksi Pemerintahan</span>
                    </div>
                  </button>

                  <button
                    id="nav-seksi-ekbang"
                    onClick={() => {
                      if (setSelectedSeksiFilter) setSelectedSeksiFilter('EKBANG');
                      setActiveView('pelayanan-list');
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list' && selectedSeksiFilter === 'EKBANG'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0"></span>
                      <span className="truncate">Seksi Ekbang</span>
                    </div>
                  </button>

                  <button
                    id="nav-seksi-pmd"
                    onClick={() => {
                      if (setSelectedSeksiFilter) setSelectedSeksiFilter('PMD');
                      setActiveView('pelayanan-list');
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list' && selectedSeksiFilter === 'PMD'
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="w-2 h-2 rounded-full bg-purple-400 shrink-0"></span>
                      <span className="truncate">Seksi PMD</span>
                    </div>
                  </button>

                  <button
                    id="nav-seksi-trantib"
                    onClick={() => {
                      if (setSelectedSeksiFilter) setSelectedSeksiFilter('TRANTIB');
                      setActiveView('pelayanan-list');
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list' && selectedSeksiFilter === 'TRANTIB'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="w-2 h-2 rounded-full bg-rose-400 shrink-0"></span>
                      <span className="truncate">Seksi Trantib</span>
                    </div>
                  </button>
                </>
              )}

              {/* L2: User Seksi Pelayanan Publik (Yanlik) */}
              {isL2 && (
                <>
                  <button
                    id="nav-l2-all"
                    onClick={() => setActiveView('pelayanan-list')}
                    className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list'
                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <HeartHandshake className="w-3.5 h-3.5 text-sky-400" />
                    <span>Daftar Pelayanan Yanlik</span>
                  </button>
                  <div className="text-[10px] text-slate-400 pt-1 pb-0.5 px-2">Katalog Layanan Yanlik:</div>
                  <div className="space-y-0.5 text-[11px] text-slate-400 pl-3">
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-400"></span> Belum Pernah Menikah
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-400"></span> Belum Punya Anak
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-400"></span> SKTM Jamkesda (400.7.3.1)
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-400"></span> SKTM KIS (400.7.3.6)
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-400"></span> SKTM KIP (400.7.3.7)
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-400"></span> SKTM Lainnya (400.7.3.2)
                    </p>
                  </div>
                </>
              )}

              {/* L3: User Seksi Pemerintahan */}
              {isL3 && (
                <>
                  <button
                    id="nav-l3-all"
                    onClick={() => setActiveView('pelayanan-list')}
                    className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <Building className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Daftar Layanan Pemerintahan</span>
                  </button>
                  <div className="text-[10px] text-slate-400 pt-1 pb-0.5 px-2">Katalog Layanan:</div>
                  <div className="space-y-0.5 text-[11px] text-slate-400 pl-3">
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Pernyataan Ahli Waris
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Legalisasi Ahli Waris WNI
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Akta Jual Beli Tanah
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> AJB Tanah Waris
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Akta Pembagian Hak (APHB)
                    </p>
                  </div>
                </>
              )}

              {/* L4: User Seksi Ekbang */}
              {isL4 && (
                <>
                  <button
                    id="nav-l4-all"
                    onClick={() => setActiveView('pelayanan-list')}
                    className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <HardHat className="w-3.5 h-3.5 text-amber-400" />
                    <span>Daftar Layanan Ekbang</span>
                  </button>
                  <div className="text-[10px] text-slate-400 pt-1 pb-0.5 px-2">Katalog Layanan:</div>
                  <div className="space-y-0.5 text-[11px] text-slate-400 pl-3">
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span> Rekomendasi PBG
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span> Rekomendasi IMB Perumahan
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span> Bangunan Tower Telekomunikasi
                    </p>
                  </div>
                </>
              )}

              {/* L5: User Seksi PMD */}
              {isL5 && (
                <>
                  <button
                    id="nav-l5-all"
                    onClick={() => setActiveView('pelayanan-list')}
                    className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list'
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <FolderOpen className="w-3.5 h-3.5 text-purple-400" />
                    <span>Daftar Layanan PMD</span>
                  </button>
                  <div className="text-[10px] text-slate-400 pt-1 pb-0.5 px-2">Katalog Layanan:</div>
                  <div className="space-y-0.5 text-[11px] text-slate-400 pl-3">
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span> Legalisasi Proposal Hibah
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span> Keterangan Domisili Haji
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span> Pendirian PAUD/TK/SD/SMP/SMK
                    </p>
                  </div>
                </>
              )}

              {/* L6: User Seksi Trantib */}
              {isL6 && (
                <>
                  <button
                    id="nav-l6-all"
                    onClick={() => setActiveView('pelayanan-list')}
                    className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md font-medium transition-all ${
                      activeView === 'pelayanan-list'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                    <span>Daftar Layanan Trantib</span>
                  </button>
                  <div className="text-[10px] text-slate-400 pt-1 pb-0.5 px-2">Katalog Layanan:</div>
                  <div className="space-y-0.5 text-[11px] text-slate-400 pl-3">
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span> Surat Izin Keramaian
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span> Legalisasi Pengantar SKCK
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span> Pendaftaran TNI / POLRI
                    </p>
                    <p className="py-0.5 flex items-center gap-1.5 truncate">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span> Pemasangan Spanduk/Reklame
                    </p>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* Laporan & Analitik */}
        <div className="space-y-1">
          <button
            onClick={() => setLaporanMenuOpen(!laporanMenuOpen)}
            className="w-full flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-2 py-1 hover:text-slate-200"
          >
            <span>Laporan & Analitik</span>
            {laporanMenuOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>
          {laporanMenuOpen && (
            <div className="space-y-1 pl-1 pt-1">
              <button
                id="nav-laporan-rekapitulasi"
                onClick={() => setActiveView('laporan-rekapitulasi')}
                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md font-medium transition-all ${
                  activeView === 'laporan-rekapitulasi'
                    ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40'
                    : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  {isL1
                    ? 'Rekapitulasi Layanan Seksi'
                    : `Rekapitulasi Seksi ${SEKSI_METADATA[currentUser.seksi!]?.short || ''}`}
                </span>
              </button>

              <button
                id="nav-laporan-grafik"
                onClick={() => setActiveView('laporan-grafik')}
                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md font-medium transition-all ${
                  activeView === 'laporan-grafik'
                    ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40'
                    : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                }`}
              >
                <PieChart className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  {isL1
                    ? 'Grafik & Statistik Terpadu'
                    : `Grafik Pelayanan Seksi ${SEKSI_METADATA[currentUser.seksi!]?.short || ''}`}
                </span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Footer Info */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/40 text-[11px] text-slate-400 space-y-2">
        <div className="flex items-center justify-between text-slate-400">
          <span>Level Akses:</span>
          <span className="font-semibold text-emerald-400">{currentUser.role}</span>
        </div>
        <p className="text-[10px] text-slate-400 line-clamp-1">
          {roleConfig.name}
        </p>

        {onLogout && (
          <button
            type="button"
            id="btn-sidebar-logout"
            onClick={onLogout}
            className="w-full mt-2 flex items-center justify-center gap-2 py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-rose-950/40 border border-slate-700 hover:border-rose-800/60 text-slate-300 hover:text-rose-300 text-xs font-semibold transition-all cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 text-slate-400 hover:text-rose-400" />
            <span>Keluar / Ganti Akun</span>
          </button>
        )}
      </div>
    </aside>
  );
};
