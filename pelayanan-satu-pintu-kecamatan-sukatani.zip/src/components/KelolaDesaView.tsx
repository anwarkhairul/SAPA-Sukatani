import React, { useState } from 'react';
import { MapPin, Plus, Edit2, Trash2, Search, Phone, Users, Home } from 'lucide-react';
import { Desa } from '../types';

interface KelolaDesaViewProps {
  desasList: Desa[];
  onAddDesa: (desa: Desa) => void;
  onUpdateDesa: (desa: Desa) => void;
  onDeleteDesa: (desaId: string) => void;
}

export const KelolaDesaView: React.FC<KelolaDesaViewProps> = ({
  desasList,
  onAddDesa,
  onUpdateDesa,
  onDeleteDesa,
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [editingDesa, setEditingDesa] = useState<Desa | null>(null);
  const [search, setSearch] = useState('');

  // Form states
  const [nama, setNama] = useState('');
  const [kodePos, setKodePos] = useState('17630');
  const [namaKepalaDesa, setNamaKepalaDesa] = useState('');
  const [kontak, setKontak] = useState('');
  const [jumlahPenduduk, setJumlahPenduduk] = useState(15000);

  const openAdd = () => {
    setEditingDesa(null);
    setNama('');
    setKodePos('17630');
    setNamaKepalaDesa('');
    setKontak('');
    setJumlahPenduduk(15000);
    setModalOpen(true);
  };

  const openEdit = (d: Desa) => {
    setEditingDesa(d);
    setNama(d.nama);
    setKodePos(d.kodePos);
    setNamaKepalaDesa(d.namaKepalaDesa);
    setKontak(d.kontak);
    setJumlahPenduduk(d.jumlahPenduduk || 0);
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nama.trim()) return;

    if (editingDesa) {
      onUpdateDesa({
        ...editingDesa,
        nama,
        kodePos,
        namaKepalaDesa,
        kontak,
        jumlahPenduduk,
      });
    } else {
      const newDesa: Desa = {
        id: `desa-${Date.now()}`,
        nama,
        kodePos,
        namaKepalaDesa,
        kontak,
        jumlahPenduduk,
      };
      onAddDesa(newDesa);
    }
    setModalOpen(false);
  };

  const filtered = desasList.filter(
    (d) =>
      d.nama.toLowerCase().includes(search.toLowerCase()) ||
      d.namaKepalaDesa.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-600" />
            <span>Kelola Data Master (Desa & Wilayah Kecamatan Sukatani)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Daftar desa binaan dalam yurisdiksi pelayanan satu pintu Kecamatan Sukatani, Kabupaten Bekasi.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Desa Baru</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
        <div className="relative w-72">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari nama desa atau kepala desa..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
          />
        </div>
        <span className="text-xs text-slate-500">
          Total: <strong>{desasList.length}</strong> Desa
        </span>
      </div>

      {/* Grid of Village cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((d, idx) => (
          <div
            key={d.id}
            className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-emerald-300 transition-colors flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-xs border border-emerald-200">
                    {idx + 1}
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-900">Desa {d.nama}</h3>
                    <p className="text-[11px] text-slate-400">Kode Pos: {d.kodePos}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openEdit(d)}
                    className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100"
                    title="Edit Desa"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  {desasList.length > 1 && (
                    <button
                      onClick={() => {
                        if (confirm(`Hapus data Desa ${d.nama}?`)) {
                          onDeleteDesa(d.id);
                        }
                      }}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50"
                      title="Hapus Desa"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <div className="mt-4 space-y-1.5 text-xs text-slate-600 border-t border-slate-100 pt-3">
                <div className="flex justify-between">
                  <span className="text-slate-400">Kepala Desa:</span>
                  <span className="font-semibold text-slate-800">{d.namaKepalaDesa || '-'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Kontak Kantor:</span>
                  <span className="font-medium text-emerald-700">{d.kontak || '-'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Estimasi Penduduk:</span>
                  <span className="font-medium text-slate-800">
                    {d.jumlahPenduduk ? `${d.jumlahPenduduk.toLocaleString('id-ID')} Jiwa` : '-'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal Add/Edit */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                {editingDesa ? 'Edit Data Desa' : 'Tambah Desa Baru'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Nama Desa *</label>
                <input
                  type="text"
                  required
                  value={nama}
                  onChange={(e) => setNama(e.target.value)}
                  placeholder="Contoh: Sukaraya"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Kode Pos</label>
                <input
                  type="text"
                  value={kodePos}
                  onChange={(e) => setKodePos(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Nama Kepala Desa / Lurah</label>
                <input
                  type="text"
                  value={namaKepalaDesa}
                  onChange={(e) => setNamaKepalaDesa(e.target.value)}
                  placeholder="Nama Kepala Desa..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Nomor Telepon Kantor Desa</label>
                <input
                  type="text"
                  value={kontak}
                  onChange={(e) => setKontak(e.target.value)}
                  placeholder="0812-xxxx-xxxx"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Estimasi Jumlah Penduduk</label>
                <input
                  type="number"
                  value={jumlahPenduduk}
                  onChange={(e) => setJumlahPenduduk(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-100 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold shadow-xs"
                >
                  Simpan Desa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
