import React, { useState, useEffect } from 'react';
import {
  X,
  FilePlus,
  User,
  CheckSquare,
  FileCheck2,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  Printer
} from 'lucide-react';
import { Desa, ServiceDefinition, ServiceRecord, ServiceSeksi, UserAccount } from '../types';
import { generateRegistrationNumber } from '../utils/numberGenerator';
import { ROLES_CONFIG, SEKSI_METADATA } from '../data/initialData';

interface InputPelayananModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount;
  services: ServiceDefinition[];
  desasList: Desa[];
  existingRecords: ServiceRecord[];
  onSaveRecord: (record: ServiceRecord, shouldPrint?: boolean) => void;
  preselectedServiceId?: string;
}

export const InputPelayananModal: React.FC<InputPelayananModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  services,
  desasList,
  existingRecords,
  onSaveRecord,
  preselectedServiceId,
}) => {
  if (!isOpen) return null;

  // Filter services based on current user's allowed section
  const allowedSeksi = ROLES_CONFIG[currentUser.role].allowedSeksi;
  const filteredServices = services.filter((s) => allowedSeksi.includes(s.seksi));

  const [selectedServiceId, setSelectedServiceId] = useState<string>(
    preselectedServiceId || (filteredServices.length > 0 ? filteredServices[0].id : '')
  );

  const activeService = services.find((s) => s.id === selectedServiceId) || filteredServices[0];

  // Citizen data states
  const [nik, setNik] = useState('');
  const [namaLengkap, setNamaLengkap] = useState('');
  const [noKk, setNoKk] = useState('');
  const [tempatLahir, setTempatLahir] = useState('Bekasi');
  const [tanggalLahir, setTanggalLahir] = useState('1990-01-01');
  const [jenisKelamin, setJenisKelamin] = useState<'L' | 'P'>('L');
  const [agama, setAgama] = useState('Islam');
  const [pekerjaan, setPekerjaan] = useState('Wiraswasta');
  const [alamat, setAlamat] = useState('');
  const [desa, setDesa] = useState(desasList[0]?.nama || 'Sukamulya');
  const [rtRw, setRtRw] = useState('001/001');
  const [noHp, setNoHp] = useState('');

  // Service details states
  const [keperluan, setKeperluan] = useState('');
  const [customFieldValues, setCustomFieldValues] = useState<Record<string, any>>({});
  const [checkedDocs, setCheckedDocs] = useState<Record<string, boolean>>({});
  const [catatanPetugas, setCatatanPetugas] = useState('');
  const [activeTab, setActiveTab] = useState<'warga' | 'layanan' | 'dokumen'>('warga');
  const [formError, setFormError] = useState('');

  // Generated registration number preview
  const [previewNumber, setPreviewNumber] = useState('');

  useEffect(() => {
    if (activeService) {
      const generated = generateRegistrationNumber(activeService, existingRecords);
      setPreviewNumber(generated);
    }
  }, [activeService, existingRecords]);

  // Handle document toggle
  const handleDocToggle = (docName: string) => {
    setCheckedDocs((prev) => ({
      ...prev,
      [docName]: !prev[docName],
    }));
  };

  const handleCustomFieldChange = (key: string, val: any) => {
    setCustomFieldValues((prev) => ({
      ...prev,
      [key]: val,
    }));
  };

  const handleSubmit = (withPrint: boolean = false) => {
    setFormError('');

    if (!nik || nik.length < 16) {
      setActiveTab('warga');
      setFormError('Nomor Induk Kependudukan (NIK) wajib diisi 16 digit.');
      return;
    }

    if (!namaLengkap.trim()) {
      setActiveTab('warga');
      setFormError('Nama lengkap pemohon wajib diisi.');
      return;
    }

    if (!alamat.trim()) {
      setActiveTab('warga');
      setFormError('Alamat domisili warga wajib diisi.');
      return;
    }

    if (!activeService) {
      setFormError('Silakan pilih jenis pelayanan.');
      return;
    }

    // Check required custom fields
    if (activeService.customFields) {
      for (const f of activeService.customFields) {
        if (f.required && !customFieldValues[f.key]) {
          setActiveTab('layanan');
          setFormError(`Kolom '${f.label}' wajib diisi.`);
          return;
        }
      }
    }

    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().substring(0, 5);

    // Calculate completion docs
    const allReqDocsChecked = activeService.syaratDokumen.every((d) => checkedDocs[d]);

    // Estimasi selesai
    const estimasi = new Date();
    estimasi.setDate(estimasi.getDate() + 2);

    const newRecord: ServiceRecord = {
      id: `rec-${Date.now()}`,
      noRegistrasi: previewNumber || generateRegistrationNumber(activeService, existingRecords),
      serviceId: activeService.id,
      serviceNama: activeService.nama,
      seksi: activeService.seksi,
      tanggalPengajuan: dateStr,
      waktuPengajuan: timeStr,
      status: allReqDocsChecked ? 'DIVERIFIKASI' : 'DRAFT',
      citizen: {
        nik,
        namaLengkap,
        noKk,
        tempatLahir,
        tanggalLahir,
        jenisKelamin,
        agama,
        pekerjaan,
        alamat,
        desa,
        rtRw,
        noHp: noHp || '-',
      },
      keperluan: keperluan || activeService.deskripsi,
      detailKhusus: customFieldValues,
      dokumenLengkap: allReqDocsChecked,
      catatanPetugas: catatanPetugas || 'Berkas telah diterima di loket PATEN Kecamatan Sukatani.',
      petugasNama: currentUser.fullName,
      petugasNip: currentUser.nip,
      estimasiSelesai: estimasi.toISOString().split('T')[0],
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };

    onSaveRecord(newRecord, withPrint);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] overflow-hidden flex flex-col border border-slate-200">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <FilePlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Formulir Input Data Pelayanan (PATEN)
              </h3>
              <p className="text-xs text-slate-500">
                Kecamatan Sukatani — Petugas: {currentUser.fullName} ({currentUser.role})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Official Code & Service Selector Banner */}
        <div className="bg-emerald-950 text-white px-6 py-3.5 flex flex-wrap items-center justify-between gap-3 border-b border-emerald-800">
          <div className="flex-1 min-w-[280px]">
            <label className="text-[10px] font-semibold text-emerald-300 uppercase tracking-wider block mb-1">
              Pilih Jenis Pelayanan:
            </label>
            <select
              value={selectedServiceId}
              onChange={(e) => {
                setSelectedServiceId(e.target.value);
                setCustomFieldValues({});
                setCheckedDocs({});
              }}
              className="w-full bg-emerald-900/90 border border-emerald-700 text-white text-xs rounded-lg px-3 py-1.5 focus:outline-hidden focus:ring-2 focus:ring-emerald-400 font-medium"
            >
              {filteredServices.map((srv) => (
                <option key={srv.id} value={srv.id}>
                  [{SEKSI_METADATA[srv.seksi]?.short}] {srv.nama}
                </option>
              ))}
            </select>
          </div>

          {/* Generated Code Display */}
          <div className="bg-emerald-900/80 px-4 py-2 rounded-lg border border-emerald-700/80">
            <span className="text-[10px] text-emerald-300 uppercase tracking-wider block font-semibold">
              Format No. Registrasi Resmi:
            </span>
            <span className="text-sm font-mono font-bold text-emerald-100 tracking-wider">
              {previewNumber}
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-100/70 px-6 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('warga')}
            className={`py-3 px-4 border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'warga'
                ? 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>1. Data Pemohon / Warga</span>
          </button>
          <button
            onClick={() => setActiveTab('layanan')}
            className={`py-3 px-4 border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'layanan'
                ? 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span>2. Rincian Pelayanan Spesifik</span>
          </button>
          <button
            onClick={() => setActiveTab('dokumen')}
            className={`py-3 px-4 border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'dokumen'
                ? 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>3. Dokumen & Berkas</span>
          </button>
        </div>

        {/* Error notification */}
        {formError && (
          <div className="mx-6 mt-4 p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
          {/* TAB 1: DATA WARGA */}
          {activeTab === 'warga' && (
            <div className="space-y-4 animate-in fade-in duration-100">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Nomor Induk Kependudukan (NIK) *
                  </label>
                  <input
                    type="text"
                    maxLength={16}
                    placeholder="Contoh: 321608..."
                    value={nik}
                    onChange={(e) => setNik(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                  <p className="text-[10px] text-slate-400 mt-0.5">16 digit sesuai e-KTP.</p>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Nomor Kartu Keluarga (KK)
                  </label>
                  <input
                    type="text"
                    maxLength={16}
                    placeholder="Contoh: 321608..."
                    value={noKk}
                    onChange={(e) => setNoKk(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1">
                    Nama Lengkap Pemohon (Sesuai KTP) *
                  </label>
                  <input
                    type="text"
                    placeholder="Nama lengkap pemohon"
                    value={namaLengkap}
                    onChange={(e) => setNamaLengkap(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs uppercase font-medium focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tempat Lahir</label>
                  <input
                    type="text"
                    value={tempatLahir}
                    onChange={(e) => setTempatLahir(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tanggal Lahir</label>
                  <input
                    type="date"
                    value={tanggalLahir}
                    onChange={(e) => setTanggalLahir(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Jenis Kelamin</label>
                  <div className="flex gap-4 pt-1">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="jk"
                        checked={jenisKelamin === 'L'}
                        onChange={() => setJenisKelamin('L')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span>Laki-laki</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="jk"
                        checked={jenisKelamin === 'P'}
                        onChange={() => setJenisKelamin('P')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span>Perempuan</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Agama</label>
                  <select
                    value={agama}
                    onChange={(e) => setAgama(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Islam">Islam</option>
                    <option value="Kristen Protestan">Kristen Protestan</option>
                    <option value="Katolik">Katolik</option>
                    <option value="Hindu">Hindu</option>
                    <option value="Buddha">Buddha</option>
                    <option value="Konghucu">Konghucu</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Pekerjaan</label>
                  <input
                    type="text"
                    value={pekerjaan}
                    onChange={(e) => setPekerjaan(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Desa (Wilayah Kecamatan Sukatani) *
                  </label>
                  <select
                    value={desa}
                    onChange={(e) => setDesa(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 font-medium"
                  >
                    {desasList.map((d) => (
                      <option key={d.id} value={d.nama}>
                        Desa {d.nama} (Kodepos: {d.kodePos})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">RT / RW</label>
                  <input
                    type="text"
                    placeholder="001/002"
                    value={rtRw}
                    onChange={(e) => setRtRw(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    No. Handphone / WhatsApp
                  </label>
                  <input
                    type="text"
                    placeholder="0812-xxxx-xxxx"
                    value={noHp}
                    onChange={(e) => setNoHp(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1">
                    Alamat Lengkap (Kampung / Jalan) *
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Nama kampung, nomor rumah, patokan"
                    value={alamat}
                    onChange={(e) => setAlamat(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('layanan')}
                  className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs"
                >
                  <span>Lanjut: Rincian Layanan</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: RINCIAN LAYANAN KHUSUS */}
          {activeTab === 'layanan' && (
            <div className="space-y-4 animate-in fade-in duration-100">
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900">
                <p className="font-bold text-sm">{activeService?.nama}</p>
                <p className="text-emerald-700 mt-0.5">{activeService?.deskripsi}</p>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Keperluan / Deskripsi Permohonan
                </label>
                <textarea
                  rows={2}
                  placeholder="Jelaskan secara singkat keperluan pembuatan berkas ini..."
                  value={keperluan}
                  onChange={(e) => setKeperluan(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Dynamic specific custom fields for this service */}
              {activeService?.customFields && activeService.customFields.length > 0 && (
                <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60 space-y-3">
                  <p className="font-bold text-slate-800 border-b border-slate-200 pb-1.5 text-xs">
                    Formulir Khusus: {activeService.nama}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {activeService.customFields.map((field) => (
                      <div key={field.key} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
                        <label className="block text-slate-700 font-medium mb-1">
                          {field.label} {field.required && <span className="text-rose-500">*</span>}
                        </label>

                        {field.type === 'select' ? (
                          <select
                            value={customFieldValues[field.key] || ''}
                            onChange={(e) => handleCustomFieldChange(field.key, e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 bg-white"
                          >
                            <option value="">-- Pilih {field.label} --</option>
                            {field.options?.map((opt) => (
                              <option key={opt} value={opt}>
                                {opt}
                              </option>
                            ))}
                          </select>
                        ) : field.type === 'textarea' ? (
                          <textarea
                            rows={2}
                            placeholder={field.placeholder || ''}
                            value={customFieldValues[field.key] || ''}
                            onChange={(e) => handleCustomFieldChange(field.key, e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 bg-white"
                          />
                        ) : (
                          <input
                            type={field.type}
                            placeholder={field.placeholder || ''}
                            value={customFieldValues[field.key] || ''}
                            onChange={(e) =>
                              handleCustomFieldChange(
                                field.key,
                                field.type === 'number' ? Number(e.target.value) : e.target.value
                              )
                            }
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 bg-white"
                          />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Catatan Petugas (Opsional)</label>
                <input
                  type="text"
                  placeholder="Catatan tambahan loket PATEN..."
                  value={catatanPetugas}
                  onChange={(e) => setCatatanPetugas(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="flex justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('warga')}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50"
                >
                  Kembali
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('dokumen')}
                  className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs"
                >
                  <span>Lanjut: Cek Berkas</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: DOKUMEN CHECKLIST */}
          {activeTab === 'dokumen' && (
            <div className="space-y-4 animate-in fade-in duration-100">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <p className="font-bold text-slate-800 text-xs mb-1">
                  Verifikasi Kelengkapan Persyaratan Fisik:
                </p>
                <p className="text-[11px] text-slate-500">
                  Centang dokumen yang telah diserahkan dan diverifikasi oleh petugas loket PATEN Kecamatan Sukatani.
                </p>
              </div>

              <div className="space-y-2">
                {activeService?.syaratDokumen.map((docName, idx) => {
                  const isChecked = !!checkedDocs[docName];
                  return (
                    <label
                      key={idx}
                      className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                        isChecked
                          ? 'bg-emerald-50/80 border-emerald-300 text-emerald-950'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => handleDocToggle(docName)}
                        className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                      />
                      <div className="flex-1">
                        <span className="font-medium text-xs">{docName}</span>
                        {isChecked && (
                          <span className="ml-2 text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-semibold">
                            Terverifikasi
                          </span>
                        )}
                      </div>
                    </label>
                  );
                })}
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-xs">
                <span className="font-bold">Info Status Registrasi: </span>
                {activeService?.syaratDokumen.every((d) => checkedDocs[d]) ? (
                  <span className="text-emerald-700 font-semibold">
                    Semua berkas lengkap. Status akan otomatis menjadi <strong>DIVERIFIKASI</strong>.
                  </span>
                ) : (
                  <span>
                    Sebagian berkas belum dicentang. Status akan disimpan sebagai <strong>DRAFT (Menunggu Kelengkapan)</strong>.
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-100 transition-colors"
          >
            Batal
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleSubmit(false)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              Simpan Data Pelayanan
            </button>
            <button
              type="button"
              onClick={() => handleSubmit(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs shadow-emerald-700/20 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Simpan & Cetak Resi</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
