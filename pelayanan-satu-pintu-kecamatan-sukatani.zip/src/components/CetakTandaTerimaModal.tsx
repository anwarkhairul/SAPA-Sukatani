import React from 'react';
import { X, Printer, CheckCircle, QrCode, FileText } from 'lucide-react';
import { ServiceRecord } from '../types';
import { formatDateIndonesian } from '../utils/numberGenerator';
import { SEKSI_METADATA } from '../data/initialData';

interface CetakTandaTerimaModalProps {
  record: ServiceRecord | null;
  isOpen: boolean;
  onClose: () => void;
}

export const CetakTandaTerimaModal: React.FC<CetakTandaTerimaModalProps> = ({
  record,
  isOpen,
  onClose,
}) => {
  if (!isOpen || !record) return null;

  const handlePrint = () => {
    window.print();
  };

  const seksiMeta = SEKSI_METADATA[record.seksi];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[95vh] overflow-hidden flex flex-col border border-slate-200 print:m-0 print:p-0 print:border-none print:shadow-none print:max-w-none print:h-auto print:static">
        {/* Header Modal - Hidden in print */}
        <div className="px-6 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50 print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-600" />
            <span className="text-xs font-bold text-slate-800">
              Pratinjau Resi / Tanda Terima Resmi
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              Cetak / Print
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200/60"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Document Content */}
        <div id="printable-receipt-area" className="p-8 overflow-y-auto font-serif text-slate-900 print:p-0">
          {/* Kop Surat Resmi */}
          <div className="text-center border-b-2 border-slate-900 pb-3 mb-4">
            <h4 className="text-xs tracking-widest uppercase font-sans font-semibold text-slate-700">
              Pemerintah Kabupaten Bekasi
            </h4>
            <h2 className="text-base font-bold uppercase tracking-wider font-sans text-slate-950">
              Kecamatan Sukatani
            </h2>
            <h3 className="text-xs font-bold uppercase tracking-wider font-sans text-emerald-800">
              Pelayanan Administrasi Terpadu Kecamatan (PATEN)
            </h3>
            <p className="text-[10px] font-sans text-slate-600 mt-0.5">
              Jl. Raya Sukatani No. 01, Sukatani, Kabupaten Bekasi, Jawa Barat 17630 — Telp: (021) 8912-3456
            </p>
          </div>

          {/* Title & Document Code */}
          <div className="text-center my-3">
            <p className="text-xs font-bold uppercase tracking-wide underline decoration-1 underline-offset-4">
              Bukti Pendaftaran & Tanda Terima Berkas
            </p>
            <p className="text-[11px] font-mono font-bold text-emerald-800 mt-1 bg-emerald-50 inline-block px-3 py-0.5 rounded border border-emerald-300">
              NO. REGISTRASI: {record.noRegistrasi}
            </p>
          </div>

          {/* Citizen & Service Info Table */}
          <div className="text-xs space-y-3 mt-4">
            <div className="border border-slate-300 rounded-md p-3 space-y-1.5 bg-slate-50/50">
              <p className="font-sans font-bold text-[11px] text-slate-800 border-b border-slate-200 pb-1">
                A. DATA PEMOHON
              </p>
              <div className="grid grid-cols-3 gap-1 text-[11px]">
                <span className="text-slate-600">Nomor Induk Kependudukan (NIK):</span>
                <span className="col-span-2 font-mono font-bold text-slate-900">{record.citizen.nik}</span>

                <span className="text-slate-600">Nama Lengkap:</span>
                <span className="col-span-2 font-bold text-slate-900 uppercase">{record.citizen.namaLengkap}</span>

                <span className="text-slate-600">Nomor Kartu Keluarga (KK):</span>
                <span className="col-span-2 font-mono text-slate-800">{record.citizen.noKk || '-'}</span>

                <span className="text-slate-600">Tempat, Tanggal Lahir:</span>
                <span className="col-span-2 text-slate-800">
                  {record.citizen.tempatLahir}, {formatDateIndonesian(record.citizen.tanggalLahir)}
                </span>

                <span className="text-slate-600">Jenis Kelamin / Agama:</span>
                <span className="col-span-2 text-slate-800">
                  {record.citizen.jenisKelamin === 'L' ? 'Laki-laki' : 'Perempuan'} / {record.citizen.agama}
                </span>

                <span className="text-slate-600">Alamat & Desa:</span>
                <span className="col-span-2 text-slate-800">
                  {record.citizen.alamat}, Desa {record.citizen.desa} (RT/RW: {record.citizen.rtRw})
                </span>

                <span className="text-slate-600">No. Telepon / WhatsApp:</span>
                <span className="col-span-2 text-slate-800">{record.citizen.noHp}</span>
              </div>
            </div>

            <div className="border border-slate-300 rounded-md p-3 space-y-1.5 bg-slate-50/50">
              <p className="font-sans font-bold text-[11px] text-slate-800 border-b border-slate-200 pb-1">
                B. RINCIAN PERMOHONAN PELAYANAN
              </p>
              <div className="grid grid-cols-3 gap-1 text-[11px]">
                <span className="text-slate-600">Jenis Pelayanan:</span>
                <span className="col-span-2 font-bold text-slate-900">{record.serviceNama}</span>

                <span className="text-slate-600">Seksi Penanggung Jawab:</span>
                <span className="col-span-2 font-medium text-slate-800">{seksiMeta.name}</span>

                <span className="text-slate-600">Keperluan / Keterangan:</span>
                <span className="col-span-2 italic text-slate-800">{record.keperluan || '-'}</span>

                {/* Specific custom fields */}
                {Object.entries(record.detailKhusus || {}).map(([key, val]) => (
                  <React.Fragment key={key}>
                    <span className="text-slate-600 capitalize">
                      {key.replace(/([A-Z])/g, ' $1')}:
                    </span>
                    <span className="col-span-2 text-slate-800 font-medium">
                      {typeof val === 'number' && key.toLowerCase().includes('nilai')
                        ? `Rp ${val.toLocaleString('id-ID')}`
                        : String(val)}
                    </span>
                  </React.Fragment>
                ))}

                <span className="text-slate-600">Waktu Pendaftaran:</span>
                <span className="col-span-2 text-slate-800">
                  {formatDateIndonesian(record.tanggalPengajuan)} pukul {record.waktuPengajuan} WIB
                </span>

                <span className="text-slate-600">Status Permohonan:</span>
                <span className="col-span-2 font-bold text-emerald-800">
                  {record.status} ({record.dokumenLengkap ? 'Berkas Lengkap' : 'Belum Lengkap'})
                </span>

                <span className="text-slate-600">Estimasi Pengambilan:</span>
                <span className="col-span-2 text-slate-800 font-medium">
                  {record.estimasiSelesai ? formatDateIndonesian(record.estimasiSelesai) : '1 - 2 Hari Kerja'}
                </span>
              </div>
            </div>
          </div>

          {/* Notes & Security Stamp */}
          <div className="mt-4 p-2.5 bg-slate-100 rounded text-[10px] text-slate-700 space-y-1">
            <p className="font-bold font-sans">PERHATIAN UNTUK PEMOHON:</p>
            <ol className="list-decimal pl-4 space-y-0.5">
              <li>Tanda terima ini adalah bukti sah registrasi berkas di loket PATEN Kecamatan Sukatani.</li>
              <li>Bawalah lembar resi ini saat pengambilan dokumen hasil pelayanan.</li>
              <li>Pelayanan administrasi terpadu di Kecamatan Sukatani TIDAK DIPUNGUT BIAYA (GRATIS), kecuali retribusi resmi yang diatur oleh Peraturan Daerah.</li>
            </ol>
          </div>

          {/* Signatures & QR Section */}
          <div className="mt-6 pt-2 grid grid-cols-3 gap-4 text-center font-sans text-xs">
            <div className="flex flex-col items-center justify-between h-28">
              <p className="text-slate-600 text-[11px]">Pemohon / Pembawa Berkas,</p>
              <p className="font-bold uppercase text-slate-900 text-[11px] underline">
                ({record.citizen.namaLengkap})
              </p>
            </div>

            {/* QR Verification */}
            <div className="flex flex-col items-center justify-center">
              <div className="w-16 h-16 border-2 border-dashed border-slate-400 rounded-lg flex items-center justify-center bg-white p-1">
                <QrCode className="w-12 h-12 text-slate-800" />
              </div>
              <span className="text-[9px] text-slate-500 mt-1 font-mono tracking-tighter">
                VERIFIED-PATEN-SUKATANI
              </span>
            </div>

            <div className="flex flex-col items-center justify-between h-28">
              <p className="text-slate-600 text-[11px]">
                Sukatani, {formatDateIndonesian(record.tanggalPengajuan)}
                <br />
                Petugas Loket PATEN,
              </p>
              <div>
                <p className="font-bold text-slate-900 text-[11px] underline">
                  {record.petugasNama}
                </p>
                <p className="text-[10px] text-slate-500 font-mono">
                  NIP. {record.petugasNip}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer info - hidden in print */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center print:hidden">
          <span className="text-xs text-slate-500">
            Kecamatan Sukatani — Sistem Pelayanan Satu Pintu
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 text-slate-700 hover:bg-slate-300 rounded-lg text-xs font-semibold transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
