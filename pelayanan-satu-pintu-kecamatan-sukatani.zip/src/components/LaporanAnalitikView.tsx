import React, { useState, useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line
} from 'recharts';
import {
  BarChart3,
  PieChart,
  FileSpreadsheet,
  Printer,
  Download,
  Calendar,
  Filter,
  CheckCircle2,
  Clock,
  Building,
  TrendingUp
} from 'lucide-react';
import { Desa, ServiceDefinition, ServiceRecord, ServiceSeksi, UserAccount } from '../types';
import { ROLES_CONFIG, SEKSI_METADATA } from '../data/initialData';

interface LaporanAnalitikViewProps {
  currentUser: UserAccount;
  records: ServiceRecord[];
  services: ServiceDefinition[];
  desasList: Desa[];
  initialTab?: 'rekapitulasi' | 'grafik';
}

const COLORS = ['#0284c7', '#059669', '#d97706', '#7c3aed', '#e11d48', '#0d9488', '#eab308'];
const STATUS_COLORS: Record<string, string> = {
  SELESAI: '#10b981',
  DIPROSES: '#0284c7',
  DIVERIFIKASI: '#6366f1',
  DRAFT: '#f59e0b',
  DITOLAK: '#f43f5e',
};

const BULAN_LIST = [
  { index: 0, nama: 'Januari' },
  { index: 1, nama: 'Februari' },
  { index: 2, nama: 'Maret' },
  { index: 3, nama: 'April' },
  { index: 4, nama: 'Mei' },
  { index: 5, nama: 'Juni' },
  { index: 6, nama: 'Juli' },
  { index: 7, nama: 'Agustus' },
  { index: 8, nama: 'September' },
  { index: 9, nama: 'Oktober' },
  { index: 10, nama: 'November' },
  { index: 11, nama: 'Desember' },
];

interface OfficialServiceConfig {
  no: number;
  nama: string;
  seksi: ServiceSeksi;
  matcher: (r: ServiceRecord) => boolean;
}

const OFFICIAL_18_SERVICES: OfficialServiceConfig[] = [
  {
    no: 1,
    nama: 'Pelayanan Registrasi Pernyataan Ahli Waris',
    seksi: 'PEMERINTAHAN',
    matcher: (r) => r.serviceId === 'srv-pem-1' || r.serviceNama.toLowerCase().includes('pernyataan ahli waris'),
  },
  {
    no: 2,
    nama: 'Pelayanan Legalisasi Keterangan Ahli Waris Warga Negara Indonesia',
    seksi: 'PEMERINTAHAN',
    matcher: (r) =>
      r.serviceId === 'srv-pem-2' ||
      (r.serviceNama.toLowerCase().includes('ahli waris') &&
        (r.serviceNama.toLowerCase().includes('wni') || r.serviceNama.toLowerCase().includes('warga negara indonesia'))),
  },
  {
    no: 3,
    nama: 'Pelayanan Registrasi Surat Keterangan Belum Pernah Menikah',
    seksi: 'YANLIK',
    matcher: (r) => r.serviceId === 'srv-yanlik-1' || r.serviceNama.toLowerCase().includes('belum pernah menikah'),
  },
  {
    no: 4,
    nama: 'Pelayanan Registrasi Surat Keterangan Belum Punya Anak',
    seksi: 'YANLIK',
    matcher: (r) => r.serviceId === 'srv-yanlik-2' || r.serviceNama.toLowerCase().includes('belum punya anak'),
  },
  {
    no: 5,
    nama: 'Pelayanan Registrasi Surat Keterangan Tidak Mampu',
    seksi: 'YANLIK',
    matcher: (r) =>
      ['srv-yanlik-3', 'srv-yanlik-4', 'srv-yanlik-5', 'srv-yanlik-6'].includes(r.serviceId) ||
      r.serviceNama.toUpperCase().includes('SKTM') ||
      r.serviceNama.toLowerCase().includes('tidak mampu'),
  },
  {
    no: 6,
    nama: 'Pelayanan Legalisasi/ Proposal Bantuan Hibah',
    seksi: 'PMD',
    matcher: (r) => r.serviceId === 'srv-pmd-1' || r.serviceNama.toLowerCase().includes('proposal') || r.serviceNama.toLowerCase().includes('hibah'),
  },
  {
    no: 7,
    nama: 'Pelayanan Surat Keterangan Domisili Haji',
    seksi: 'PMD',
    matcher: (r) => r.serviceId === 'srv-pmd-2' || r.serviceNama.toLowerCase().includes('domisili haji') || r.serviceNama.toLowerCase().includes('haji'),
  },
  {
    no: 8,
    nama: 'Pelayanan Rekomendasi Pendirian PAUD/TK/SD/SMP/SMK',
    seksi: 'PMD',
    matcher: (r) =>
      r.serviceId === 'srv-pmd-3' ||
      r.serviceNama.toLowerCase().includes('pendirian paud') ||
      r.serviceNama.toLowerCase().includes('pendidikan'),
  },
  {
    no: 9,
    nama: 'Pelayanan Rekomendasi Persetujuan Bangunan Gedung',
    seksi: 'EKBANG',
    matcher: (r) =>
      r.serviceId === 'srv-ekbang-1' ||
      r.serviceNama.toLowerCase().includes('persetujuan bangunan gedung') ||
      r.serviceNama.toUpperCase().includes('PBG'),
  },
  {
    no: 10,
    nama: 'Pelayanan Rekomendasi Pengajuan IMB Perumahan',
    seksi: 'EKBANG',
    matcher: (r) =>
      r.serviceId === 'srv-ekbang-2' ||
      r.serviceNama.toLowerCase().includes('imb perumahan') ||
      r.serviceNama.toLowerCase().includes('perumahan'),
  },
  {
    no: 11,
    nama: 'Pelayanan Rekomendasi Persetujuan Bangunan Tower',
    seksi: 'EKBANG',
    matcher: (r) =>
      r.serviceId === 'srv-ekbang-3' ||
      r.serviceNama.toLowerCase().includes('bangunan tower') ||
      r.serviceNama.toLowerCase().includes('tower'),
  },
  {
    no: 12,
    nama: 'Pelayanan Surat Ijin Keramaian',
    seksi: 'TRANTIB',
    matcher: (r) =>
      r.serviceId === 'srv-trantib-1' ||
      r.serviceNama.toLowerCase().includes('ijin keramaian') ||
      r.serviceNama.toLowerCase().includes('izin keramaian'),
  },
  {
    no: 13,
    nama: 'Pelayanan Legalisasi Surat Keterangan (Pengajuan Surat Keterangan Catatan Kepolisian /SKCK)',
    seksi: 'TRANTIB',
    matcher: (r) =>
      r.serviceId === 'srv-trantib-2' ||
      r.serviceNama.toUpperCase().includes('SKCK') ||
      r.serviceNama.toLowerCase().includes('catatan kepolisian'),
  },
  {
    no: 14,
    nama: 'Pelayanan Permohonan Pemasangan Spanduk/Umbul-umbul',
    seksi: 'TRANTIB',
    matcher: (r) =>
      r.serviceId === 'srv-trantib-4' ||
      r.serviceNama.toLowerCase().includes('spanduk') ||
      r.serviceNama.toLowerCase().includes('umbul-umbul'),
  },
  {
    no: 15,
    nama: 'Pelayanan Akta Jual Beli Tanah',
    seksi: 'PEMERINTAHAN',
    matcher: (r) =>
      r.serviceId === 'srv-pem-3' ||
      (r.serviceNama.toLowerCase().includes('jual beli tanah') && !r.serviceNama.toLowerCase().includes('waris')),
  },
  {
    no: 16,
    nama: 'Pelayanan Akta Jual Beli Tanah Waris',
    seksi: 'PEMERINTAHAN',
    matcher: (r) =>
      r.serviceId === 'srv-pem-4' ||
      (r.serviceNama.toLowerCase().includes('jual beli tanah') && r.serviceNama.toLowerCase().includes('waris')),
  },
  {
    no: 17,
    nama: 'Pelayanan Akta Pembagian Hak Bersama',
    seksi: 'PEMERINTAHAN',
    matcher: (r) =>
      r.serviceId === 'srv-pem-5' ||
      r.serviceNama.toLowerCase().includes('pembagian hak bersama') ||
      r.serviceNama.toUpperCase().includes('APHB'),
  },
  {
    no: 18,
    nama: 'Pelayanan Legalisasi Surat Keterangan (Persyaratan Pendaftaran TNI/POLRI)',
    seksi: 'TRANTIB',
    matcher: (r) =>
      r.serviceId === 'srv-trantib-3' ||
      r.serviceNama.toUpperCase().includes('TNI/POLRI') ||
      r.serviceNama.toUpperCase().includes('POLRI') ||
      r.serviceNama.toUpperCase().includes('TNI'),
  },
];

export const LaporanAnalitikView: React.FC<LaporanAnalitikViewProps> = ({
  currentUser,
  records,
  services,
  desasList,
  initialTab = 'rekapitulasi',
}) => {
  const isL1 = currentUser.role === 'L1';
  const userRoleConfig = ROLES_CONFIG[currentUser.role];
  const [activeTab, setActiveTab] = useState<'rekapitulasi' | 'grafik'>(initialTab);
  const [filterSeksi, setFilterSeksi] = useState<ServiceSeksi | 'ALL'>('ALL');
  const [filterYear, setFilterYear] = useState<number>(2026);

  // Filter records based on role scope
  const scopedRecords = useMemo(() => {
    return records.filter((r) => {
      // Role enforcement
      if (!isL1 && r.seksi !== currentUser.seksi) {
        return false;
      }
      // If L1 and filter selected
      if (isL1 && filterSeksi !== 'ALL' && r.seksi !== filterSeksi) {
        return false;
      }
      const year = new Date(r.tanggalPengajuan).getFullYear();
      if (filterYear && year !== filterYear) {
        return false;
      }
      return true;
    });
  }, [records, isL1, currentUser.seksi, filterSeksi, filterYear]);

  // Statistics calculation
  const totalCount = scopedRecords.length;
  const selesaiCount = scopedRecords.filter((r) => r.status === 'SELESAI').length;
  const prosesCount = scopedRecords.filter((r) => r.status === 'DIPROSES' || r.status === 'DIVERIFIKASI').length;
  const draftCount = scopedRecords.filter((r) => r.status === 'DRAFT').length;
  const completionRate = totalCount > 0 ? Math.round((selesaiCount / totalCount) * 100) : 0;

  // Data for Seksi breakdown chart (for L1)
  const seksiChartData = useMemo(() => {
    const seksiList: ServiceSeksi[] = ['YANLIK', 'PEMERINTAHAN', 'EKBANG', 'PMD', 'TRANTIB'];
    return seksiList.map((s) => {
      const recs = records.filter((r) => r.seksi === s);
      return {
        name: SEKSI_METADATA[s].short,
        total: recs.length,
        selesai: recs.filter((r) => r.status === 'SELESAI').length,
        proses: recs.filter((r) => r.status === 'DIPROSES' || r.status === 'DIVERIFIKASI').length,
      };
    });
  }, [records]);

  // Data for Desa breakdown
  const desaChartData = useMemo(() => {
    return desasList.map((d) => {
      const count = scopedRecords.filter((r) => r.citizen.desa === d.nama).length;
      return {
        name: d.nama,
        jumlah: count,
      };
    });
  }, [desasList, scopedRecords]);

  // Data for Status distribution pie chart
  const statusPieData = useMemo(() => {
    const statuses = ['SELESAI', 'DIPROSES', 'DIVERIFIKASI', 'DRAFT', 'DITOLAK'];
    return statuses
      .map((st) => ({
        name: st,
        value: scopedRecords.filter((r) => r.status === st).length,
      }))
      .filter((item) => item.value > 0);
  }, [scopedRecords]);

  // Top services chart data
  const topServicesData = useMemo(() => {
    const counts: Record<string, number> = {};
    scopedRecords.forEach((r) => {
      counts[r.serviceNama] = (counts[r.serviceNama] || 0) + 1;
    });
    return Object.entries(counts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 6);
  }, [scopedRecords]);

  // Official Matrix calculation matching the Sukatani official template
  const matrixRows = useMemo(() => {
    let targetList = [...OFFICIAL_18_SERVICES];

    // Append any custom services registered in system that are not in the standard 18 list
    const extraServices = services.filter(
      (s) => !OFFICIAL_18_SERVICES.some((item) => item.matcher({ serviceId: s.id, serviceNama: s.nama } as ServiceRecord))
    );
    extraServices.forEach((extra, idx) => {
      targetList.push({
        no: OFFICIAL_18_SERVICES.length + idx + 1,
        nama: extra.nama,
        seksi: extra.seksi,
        matcher: (r) => r.serviceId === extra.id,
      });
    });

    // Filter if not L1 or if specific seksi is selected
    if (!isL1) {
      targetList = targetList.filter((s) => s.seksi === currentUser.seksi);
    } else if (filterSeksi !== 'ALL') {
      targetList = targetList.filter((s) => s.seksi === filterSeksi);
    }

    return targetList.map((item, idx) => {
      const monthlyCounts = BULAN_LIST.map((b) => {
        return scopedRecords.filter((r) => {
          if (!item.matcher(r)) return false;
          const parts = r.tanggalPengajuan ? r.tanggalPengajuan.split('-') : [];
          if (parts.length >= 2) {
            const m = parseInt(parts[1], 10) - 1;
            return m === b.index;
          }
          return false;
        }).length;
      });

      const rowTotal = monthlyCounts.reduce((acc, curr) => acc + curr, 0);

      return {
        no: isL1 && filterSeksi === 'ALL' ? item.no : idx + 1,
        nama: item.nama,
        seksi: item.seksi,
        monthlyCounts,
        total: rowTotal,
      };
    });
  }, [services, isL1, currentUser.seksi, filterSeksi, scopedRecords]);

  // Monthly sums across all rows
  const monthlyTotals = useMemo(() => {
    return BULAN_LIST.map((b) => {
      return matrixRows.reduce((acc, row) => acc + row.monthlyCounts[b.index], 0);
    });
  }, [matrixRows]);

  const grandTotal = useMemo(() => {
    return monthlyTotals.reduce((acc, curr) => acc + curr, 0);
  }, [monthlyTotals]);

  const handleExportCSV = () => {
    const headers = ['No', 'Jenis Pelayanan', ...BULAN_LIST.map((b) => b.nama), 'Total Jumlah'];
    const csvRows: (string | number)[][] = [
      ['Matriks Rekapitulasi Pelayanan per Bulan'],
      ['Kecamatan Sukatani Kabupaten Bekasi'],
      [`Tahun ${filterYear}`],
      [],
      headers,
    ];

    matrixRows.forEach((row) => {
      csvRows.push([
        row.no,
        `"${row.nama.replace(/"/g, '""')}"`,
        ...BULAN_LIST.map((b) => (row.monthlyCounts[b.index] > 0 ? row.monthlyCounts[b.index] : 0)),
        row.total,
      ]);
    });

    csvRows.push([
      'Jumlah Pelayanan',
      '',
      ...BULAN_LIST.map((b) => monthlyTotals[b.index]),
      grandTotal,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + csvRows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Matriks_Rekapitulasi_Pelayanan_Sukatani_${filterYear}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  const currentSeksiMeta = currentUser.seksi ? SEKSI_METADATA[currentUser.seksi] : null;

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-2xs print:hidden">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span>Laporan Rekapitulasi & Analitik Pelayanan</span>
            {!isL1 && currentSeksiMeta && (
              <span className={`text-xs px-2 py-0.5 rounded-md font-semibold border ${currentSeksiMeta.badgeBg} ${currentSeksiMeta.badgeBorder}`}>
                {currentSeksiMeta.name}
              </span>
            )}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {isL1
              ? 'Laporan konsolidasi seluruh seksi pelayanan satu pintu Kecamatan Sukatani.'
              : `Laporan dan analitik data khusus ${userRoleConfig.name}.`}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Tab Switcher */}
          <div className="bg-slate-100 p-1 rounded-lg flex items-center gap-1 text-xs">
            <button
              onClick={() => setActiveTab('rekapitulasi')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-semibold transition-all ${
                activeTab === 'rekapitulasi'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Tabel Rekapitulasi</span>
            </button>
            <button
              onClick={() => setActiveTab('grafik')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-semibold transition-all ${
                activeTab === 'grafik'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Grafik Pelayanan</span>
            </button>
          </div>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak Laporan</span>
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 print:grid-cols-4">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            Total Permohonan
          </span>
          <div className="text-2xl font-bold text-slate-900 mt-1">{totalCount}</div>
          <p className="text-[10px] text-slate-400 mt-0.5">Berkas masuk terdata</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-semibold text-emerald-600 uppercase tracking-wider block">
            Selesai Diproses
          </span>
          <div className="text-2xl font-bold text-emerald-700 mt-1">{selesaiCount}</div>
          <p className="text-[10px] text-emerald-600 mt-0.5">{completionRate}% tingkat penyelesaian</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-semibold text-sky-600 uppercase tracking-wider block">
            Dalam Proses Verifikasi
          </span>
          <div className="text-2xl font-bold text-sky-700 mt-1">{prosesCount}</div>
          <p className="text-[10px] text-sky-600 mt-0.5">Tindak lanjut seksi teknis</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-semibold text-amber-600 uppercase tracking-wider block">
            Draft / Menunggu Syarat
          </span>
          <div className="text-2xl font-bold text-amber-700 mt-1">{draftCount}</div>
          <p className="text-[10px] text-amber-600 mt-0.5">Menunggu kelengkapan fisik</p>
        </div>
      </div>

      {/* Filter Row for Reports - Hidden in Print */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs print:hidden">
        <div className="flex items-center gap-2">
          {isL1 && (
            <select
              value={filterSeksi}
              onChange={(e) => setFilterSeksi(e.target.value as ServiceSeksi | 'ALL')}
              className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-800 font-medium focus:ring-2 focus:ring-emerald-500"
            >
              <option value="ALL">Semua Seksi Pelayanan</option>
              <option value="YANLIK">Seksi Yanlik</option>
              <option value="PEMERINTAHAN">Seksi Pemerintahan</option>
              <option value="EKBANG">Seksi Ekbang</option>
              <option value="PMD">Seksi PMD</option>
              <option value="TRANTIB">Seksi Trantib</option>
            </select>
          )}

          <select
            id="dropdown-tahun-berjalan"
            value={filterYear}
            onChange={(e) => setFilterYear(Number(e.target.value))}
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-800 font-medium focus:ring-2 focus:ring-emerald-500 cursor-pointer"
          >
            <option value={2026}>Tahun Berjalan (2026)</option>
            <option value={2025}>Tahun 2025</option>
            <option value={2027}>Tahun 2027</option>
            <option value={2028}>Tahun 2028</option>
            <option value={2029}>Tahun 2029</option>
            <option value={2030}>Tahun 2030</option>
          </select>
        </div>

        <span className="text-slate-500 text-[11px]">
          Data teragregasi secara otomatis dan real-time.
        </span>
      </div>

      {/* TAB 1: REKAPITULASI TABLE */}
      {activeTab === 'rekapitulasi' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-4 sm:p-6 overflow-hidden">
          {/* Action & Info Bar - Hidden in Print */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-5 pb-4 border-b border-slate-200 print:hidden">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Matriks Rekapitulasi Pelayanan per Bulan (Tahun {filterYear})
              </h3>
              <p className="text-[11px] text-slate-500">
                Format resmi rekapitulasi pelayanan Kecamatan Sukatani sesuai dokumen baku 18 jenis pelayanan.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportCSV}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold shadow-xs transition-colors"
                title="Unduh data dalam format CSV / Excel"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>Unduh Excel (CSV)</span>
              </button>

              <button
                onClick={handlePrint}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
                title="Cetak format lanskap dokumen"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Cetak Dokumen</span>
              </button>
            </div>
          </div>

          {/* Centered Document Header matching official format */}
          <div className="text-center mb-5 space-y-0.5">
            <h2 className="text-sm sm:text-base font-bold text-black tracking-normal">
              Matriks Rekapitulasi Pelayanan per Bulan
            </h2>
            <h3 className="text-xs sm:text-sm font-bold text-black">
              Kecamatan Sukatani Kabupaten Bekasi
            </h3>
            <p className="text-xs sm:text-sm font-bold text-black">
              Tahun {filterYear}
            </p>
          </div>

          {/* Official Matrix Table */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-black text-black text-xs">
              <thead>
                {/* Header Row 1 */}
                <tr className="bg-[#00FFFF]">
                  <th
                    rowSpan={2}
                    className="border border-black bg-[#00FFFF] text-black font-bold text-center py-2 px-2 w-12"
                  >
                    No
                  </th>
                  <th
                    rowSpan={2}
                    className="border border-black bg-[#00FFFF] text-black font-bold text-center py-2 px-3 min-w-[280px]"
                  >
                    Jenis Pelayanan
                  </th>
                  <th
                    colSpan={13}
                    className="border border-black bg-[#00FFFF] text-black font-bold text-center py-1.5"
                  >
                    Jumlah
                  </th>
                </tr>
                {/* Header Row 2 */}
                <tr className="bg-[#00FFFF]">
                  {BULAN_LIST.map((b) => (
                    <th
                      key={b.index}
                      className="border border-black bg-[#00FFFF] text-black font-semibold text-center text-[11px] py-1.5 px-1 min-w-[55px]"
                    >
                      {b.nama}
                    </th>
                  ))}
                  <th className="border border-black bg-[#00FFFF] text-black font-semibold text-center text-[11px] py-1.5 px-2 min-w-[75px]">
                    Total Jumlah
                  </th>
                </tr>
              </thead>
              <tbody>
                {matrixRows.map((row) => (
                  <tr key={row.no} className="hover:bg-cyan-50/20 bg-white">
                    <td className="border border-black text-center py-1.5 px-2 font-normal text-black">
                      {row.no}
                    </td>
                    <td className="border border-black text-left py-1.5 px-3 font-normal text-black">
                      {row.nama}
                    </td>
                    {BULAN_LIST.map((b) => {
                      const count = row.monthlyCounts[b.index];
                      return (
                        <td
                          key={b.index}
                          className="border border-black text-center py-1.5 px-1 font-normal text-black"
                        >
                          {count > 0 ? count : ''}
                        </td>
                      );
                    })}
                    <td className="border border-black text-center py-1.5 px-2 font-normal text-black">
                      {row.total}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-white font-bold">
                  <td
                    colSpan={2}
                    className="border border-black text-center py-2 px-3 font-bold text-black"
                  >
                    Jumlah Pelayanan
                  </td>
                  {BULAN_LIST.map((b) => (
                    <td
                      key={b.index}
                      className="border border-black text-center py-2 px-1 font-bold text-black"
                    >
                      {monthlyTotals[b.index]}
                    </td>
                  ))}
                  <td className="border border-black text-center py-2 px-2 font-bold text-black">
                    {grandTotal}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: GRAFIK PELAYANAN */}
      {activeTab === 'grafik' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Chart 1: Per Seksi (for Admin) or Status Distribution (for Single Seksi) */}
          {isL1 && filterSeksi === 'ALL' ? (
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                Grafik Komparasi Pelayanan Antar Seksi
              </h3>
              <p className="text-[11px] text-slate-500 mb-4">
                Total permohonan yang ditangani oleh kelima seksi di Kecamatan Sukatani.
              </p>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={seksiChartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                    <Bar dataKey="total" fill="#0284c7" name="Total Berkas" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="selesai" fill="#10b981" name="Selesai" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          ) : (
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                Grafik Status Penyelesaian Berkas
              </h3>
              <p className="text-[11px] text-slate-500 mb-4">
                Persentase status berkas dalam pelayanan aktif.
              </p>
              <div className="h-64">
                {statusPieData.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-slate-400 text-xs">
                    Belum ada data permohonan untuk ditampilkan.
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={statusPieData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                      >
                        {statusPieData.map((entry) => (
                          <Cell key={entry.name} fill={STATUS_COLORS[entry.name] || '#94a3b8'} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RePieChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>
          )}

          {/* Chart 2: Per Desa */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
              Distribusi Pemohon Berdasarkan Desa
            </h3>
            <p className="text-[11px] text-slate-500 mb-4">
              Sebaran jumlah warga pemohon dari 7 desa di wilayah Kecamatan Sukatani.
            </p>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={desaChartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="jumlah" fill="#059669" name="Jumlah Permohonan" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 3: Top Jenis Layanan */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs lg:col-span-2">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
              Jenis Pelayanan Paling Sering Diajukan Warga
            </h3>
            <p className="text-[11px] text-slate-500 mb-4">
              Peringkat layanan dengan volume registrasi tertinggi di loket PATEN.
            </p>
            <div className="h-56">
              {topServicesData.length === 0 ? (
                <div className="h-full flex items-center justify-center text-slate-400 text-xs">
                  Belum ada data pelayanan yang diajukan.
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={topServicesData} layout="vertical" margin={{ left: 100 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                    <XAxis type="number" tick={{ fontSize: 11 }} />
                    <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={180} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#7c3aed" name="Jumlah Berkas" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
