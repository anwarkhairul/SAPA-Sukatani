import React, { useState, useEffect } from 'react';
import {
  INITIAL_DESA,
  INITIAL_RECORDS,
  INITIAL_SERVICES,
  INITIAL_USERS,
  ROLES_CONFIG
} from './data/initialData';
import { Desa, ServiceDefinition, ServiceRecord, ServiceSeksi, ServiceStatus, UserAccount } from './types';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardOverview } from './components/DashboardOverview';
import { DataPelayananTable } from './components/DataPelayananTable';
import { InputPelayananModal } from './components/InputPelayananModal';
import { DetailPelayananModal } from './components/DetailPelayananModal';
import { CetakTandaTerimaModal } from './components/CetakTandaTerimaModal';
import { HakAksesMatrixModal } from './components/HakAksesMatrixModal';
import { KelolaUserView } from './components/KelolaUserView';
import { KelolaDesaView } from './components/KelolaDesaView';
import { KelolaJenisPelayananView } from './components/KelolaJenisPelayananView';
import { LaporanAnalitikView } from './components/LaporanAnalitikView';
import { LoginForm } from './components/LoginForm';
import { CheckCircle2, AlertCircle } from 'lucide-react';

export default function App() {
  // Persistence initialization
  const [users, setUsers] = useState<UserAccount[]>(() => {
    const USER_MASTER_VERSION = 'v2_khairul_anwar_admin';
    const savedVer = localStorage.getItem('sukatani_user_version');
    if (savedVer !== USER_MASTER_VERSION) {
      localStorage.setItem('sukatani_user_version', USER_MASTER_VERSION);
      const saved = localStorage.getItem('sukatani_users');
      if (saved) {
        try {
          const parsed: UserAccount[] = JSON.parse(saved);
          const hasL1 = parsed.some((u) => u.nip === '198108122008011002');
          if (!hasL1) {
            const updated = parsed.map((u) => {
              if (u.id === 'usr-1' || u.role === 'L1') {
                return {
                  ...u,
                  id: 'usr-1',
                  fullName: 'Khairul Anwar, S.Pdi',
                  nip: '198108122008011002',
                  role: 'L1' as const,
                  email: 'khairul.anwar@sukatani.bekasikab.go.id',
                  jabatan: 'Koordinator PATEN & Admin Sistem',
                };
              }
              return u;
            });
            localStorage.setItem('sukatani_users', JSON.stringify(updated));
            return updated;
          }
        } catch {
          // fallback
        }
      }
      localStorage.setItem('sukatani_users', JSON.stringify(INITIAL_USERS));
      return INITIAL_USERS;
    }
    const saved = localStorage.getItem('sukatani_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<UserAccount>(() => {
    const savedId = localStorage.getItem('sukatani_current_user_id');
    let found = users.find((u) => u.id === savedId);
    if (!found) {
      found = users.find((u) => u.nip === '198108122008011002') || users[0] || INITIAL_USERS[0];
    }
    return found;
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const savedAuth = localStorage.getItem('sukatani_is_authenticated');
    return savedAuth === 'true';
  });

  const [desasList, setDesasList] = useState<Desa[]>(() => {
    const DESA_MASTER_VERSION = 'v2_sukatani_7_desa';
    const savedVer = localStorage.getItem('sukatani_desa_version');
    if (savedVer !== DESA_MASTER_VERSION) {
      localStorage.setItem('sukatani_desa_version', DESA_MASTER_VERSION);
      localStorage.setItem('sukatani_desa', JSON.stringify(INITIAL_DESA));
      return INITIAL_DESA;
    }
    const saved = localStorage.getItem('sukatani_desa');
    return saved ? JSON.parse(saved) : INITIAL_DESA;
  });

  const [services, setServices] = useState<ServiceDefinition[]>(() => {
    const saved = localStorage.getItem('sukatani_services');
    return saved ? JSON.parse(saved) : INITIAL_SERVICES;
  });

  const [records, setRecords] = useState<ServiceRecord[]>(() => {
    // Clean demo records migration check
    const demoCleaned = localStorage.getItem('sukatani_demo_cleaned_v1');
    if (!demoCleaned) {
      localStorage.setItem('sukatani_demo_cleaned_v1', 'true');
      localStorage.setItem('sukatani_records', JSON.stringify([]));
      return [];
    }
    const saved = localStorage.getItem('sukatani_records');
    if (!saved) return INITIAL_RECORDS;
    try {
      const parsed: ServiceRecord[] = JSON.parse(saved);
      // Ensure any legacy demo IDs (rec-2026-001 ... 006) are cleared
      const cleaned = parsed.filter((r) => !r.id.startsWith('rec-2026-'));
      return cleaned;
    } catch {
      return [];
    }
  });

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('sukatani_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('sukatani_desa', JSON.stringify(desasList));
  }, [desasList]);

  useEffect(() => {
    localStorage.setItem('sukatani_services', JSON.stringify(services));
  }, [services]);

  useEffect(() => {
    localStorage.setItem('sukatani_records', JSON.stringify(records));
  }, [records]);

  useEffect(() => {
    localStorage.setItem('sukatani_current_user_id', currentUser.id);
  }, [currentUser]);

  // Views & filters state
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [selectedSeksiFilter, setSelectedSeksiFilter] = useState<ServiceSeksi | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals state
  const [inputModalOpen, setInputModalOpen] = useState(false);
  const [preselectedServiceId, setPreselectedServiceId] = useState<string | undefined>();
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [selectedRecordForDetail, setSelectedRecordForDetail] = useState<ServiceRecord | null>(null);
  const [printModalOpen, setPrintModalOpen] = useState(false);
  const [selectedRecordForPrint, setSelectedRecordForPrint] = useState<ServiceRecord | null>(null);
  const [infoMatrixOpen, setInfoMatrixOpen] = useState(false);

  // Toast alert state
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' } | null>(null);

  const showToast = (text: string, type: 'success' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // User Switcher handler
  const handleSwitchUser = (newUser: UserAccount) => {
    setCurrentUser(newUser);

    // If active view was restricted master data and switched to non-L1, redirect to dashboard
    if (newUser.role !== 'L1' && ['master-user', 'master-desa', 'master-layanan'].includes(activeView)) {
      setActiveView('dashboard');
    }

    if (newUser.seksi) {
      setSelectedSeksiFilter(newUser.seksi);
    } else {
      setSelectedSeksiFilter('ALL');
    }

    showToast(`Beralih ke: ${newUser.fullName} (${ROLES_CONFIG[newUser.role].shortName})`, 'info');
  };

  // Login & Logout Handlers
  const handleLoginSuccess = (user: UserAccount) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
    localStorage.setItem('sukatani_is_authenticated', 'true');
    localStorage.setItem('sukatani_current_user_id', user.id);

    if (user.seksi) {
      setSelectedSeksiFilter(user.seksi);
    } else {
      setSelectedSeksiFilter('ALL');
    }

    if (user.role !== 'L1' && ['master-user', 'master-desa', 'master-layanan'].includes(activeView)) {
      setActiveView('dashboard');
    }

    showToast(`Selamat datang, ${user.fullName} (${ROLES_CONFIG[user.role].shortName})`, 'success');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('sukatani_is_authenticated');
    showToast('Sesi telah keluar. Silakan masukkan Kode Akses NIP untuk masuk kembali.', 'info');
  };

  // If user is not authenticated, render Login Form
  if (!isAuthenticated) {
    return (
      <>
        {toastMessage && (
          <div className="fixed bottom-5 right-5 z-50 animate-in slide-in-from-bottom-5 fade-in duration-200">
            <div className="flex items-center gap-2.5 px-4 py-3 bg-slate-900 text-white rounded-xl shadow-xl border border-slate-700 text-xs font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{toastMessage.text}</span>
            </div>
          </div>
        )}
        <LoginForm users={users} onLogin={handleLoginSuccess} />
      </>
    );
  }

  // Save new record
  const handleSaveRecord = (newRec: ServiceRecord, shouldPrint: boolean = false) => {
    setRecords((prev) => [newRec, ...prev]);
    showToast(`Data pelayanan No. ${newRec.noRegistrasi} berhasil disimpan!`);

    if (shouldPrint) {
      setSelectedRecordForPrint(newRec);
      setPrintModalOpen(true);
    }
  };

  // Update record status
  const handleUpdateRecordStatus = (recordId: string, newStatus: ServiceStatus, catatan?: string) => {
    setRecords((prev) =>
      prev.map((r) =>
        r.id === recordId
          ? {
              ...r,
              status: newStatus,
              catatanPetugas: catatan || r.catatanPetugas,
              tanggalSelesai: newStatus === 'SELESAI' ? new Date().toISOString().split('T')[0] : r.tanggalSelesai,
              updatedAt: new Date().toISOString(),
            }
          : r
      )
    );
    showToast(`Status permohonan berhasil diubah menjadi: ${newStatus}`);
  };

  // Delete record (Admin only)
  const handleDeleteRecord = (recordId: string) => {
    setRecords((prev) => prev.filter((r) => r.id !== recordId));
    showToast(`Data pelayanan berhasil dihapus.`, 'info');
  };

  // Open new service modal
  const handleOpenNewServiceModal = (srvId?: string) => {
    setPreselectedServiceId(srvId);
    setInputModalOpen(true);
  };

  // Open detail
  const handleOpenDetail = (record: ServiceRecord) => {
    setSelectedRecordForDetail(record);
    setDetailModalOpen(true);
  };

  // Open print
  const handleOpenPrint = (record: ServiceRecord) => {
    setSelectedRecordForPrint(record);
    setPrintModalOpen(true);
  };

  // Master User handlers
  const handleAddUser = (user: UserAccount) => {
    setUsers((prev) => [...prev, user]);
    showToast(`Pengguna baru ${user.fullName} berhasil ditambahkan!`);
  };

  const handleUpdateUser = (user: UserAccount) => {
    setUsers((prev) => prev.map((u) => (u.id === user.id ? user : u)));
    if (currentUser.id === user.id) {
      setCurrentUser(user);
    }
    showToast(`Data pengguna ${user.fullName} berhasil diperbarui!`);
  };

  const handleDeleteUser = (userId: string) => {
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    showToast(`Pengguna berhasil dihapus.`, 'info');
  };

  // Master Desa handlers
  const handleAddDesa = (desa: Desa) => {
    setDesasList((prev) => [...prev, desa]);
    showToast(`Desa ${desa.nama} berhasil ditambahkan!`);
  };

  const handleUpdateDesa = (desa: Desa) => {
    setDesasList((prev) => prev.map((d) => (d.id === desa.id ? desa : d)));
    showToast(`Data Desa ${desa.nama} berhasil diperbarui!`);
  };

  const handleDeleteDesa = (desaId: string) => {
    setDesasList((prev) => prev.filter((d) => d.id !== desaId));
    showToast(`Desa berhasil dihapus.`, 'info');
  };

  // Master Layanan handlers
  const handleAddService = (service: ServiceDefinition) => {
    setServices((prev) => [...prev, service]);
    showToast(`Jenis pelayanan "${service.nama}" berhasil ditambahkan!`);
  };

  const handleUpdateService = (service: ServiceDefinition) => {
    setServices((prev) => prev.map((s) => (s.id === service.id ? service : s)));
    showToast(`Jenis pelayanan "${service.nama}" berhasil diperbarui!`);
  };

  const handleDeleteService = (serviceId: string) => {
    setServices((prev) => prev.filter((s) => s.id !== serviceId));
    showToast(`Jenis pelayanan berhasil dihapus.`, 'info');
  };

  return (
    <div className="flex h-screen bg-slate-100 overflow-hidden font-sans">
      {/* Toast notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 animate-in slide-in-from-bottom-5 fade-in duration-200">
          <div className="flex items-center gap-2.5 px-4 py-3 bg-slate-900 text-white rounded-xl shadow-xl border border-slate-700 text-xs font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Sidebar navigation */}
      <Sidebar
        currentUser={currentUser}
        activeView={activeView}
        setActiveView={setActiveView}
        selectedSeksiFilter={selectedSeksiFilter}
        setSelectedSeksiFilter={setSelectedSeksiFilter}
        onOpenNewServiceModal={handleOpenNewServiceModal}
        onLogout={handleLogout}
      />

      {/* Main content area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header with Role Switcher */}
        <Header
          currentUser={currentUser}
          onSwitchUser={handleSwitchUser}
          onOpenNewServiceModal={() => handleOpenNewServiceModal()}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          onOpenInfoModal={() => setInfoMatrixOpen(true)}
          onLogout={handleLogout}
        />

        {/* Dynamic Main Body Scrollable */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* View 1: Dashboard Overview */}
            {activeView === 'dashboard' && (
              <DashboardOverview
                currentUser={currentUser}
                records={records}
                services={services}
                desasList={desasList}
                onOpenNewServiceModal={handleOpenNewServiceModal}
                onOpenDetail={handleOpenDetail}
                onOpenPrint={handleOpenPrint}
                onNavigateView={setActiveView}
                onOpenInfoMatrix={() => setInfoMatrixOpen(true)}
              />
            )}

            {/* View 2: Daftar Pelayanan Table */}
            {activeView === 'pelayanan-list' && (
              <DataPelayananTable
                currentUser={currentUser}
                records={records}
                desasList={desasList}
                onOpenDetail={handleOpenDetail}
                onOpenPrint={handleOpenPrint}
                onOpenNewServiceModal={() => handleOpenNewServiceModal()}
                selectedSeksiFilter={selectedSeksiFilter}
                setSelectedSeksiFilter={setSelectedSeksiFilter}
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
              />
            )}

            {/* View 3: Master User (Admin L1 only) */}
            {activeView === 'master-user' && currentUser.role === 'L1' && (
              <KelolaUserView
                users={users}
                onAddUser={handleAddUser}
                onUpdateUser={handleUpdateUser}
                onDeleteUser={handleDeleteUser}
              />
            )}

            {/* View 4: Master Desa (Admin L1 only) */}
            {activeView === 'master-desa' && currentUser.role === 'L1' && (
              <KelolaDesaView
                desasList={desasList}
                onAddDesa={handleAddDesa}
                onUpdateDesa={handleUpdateDesa}
                onDeleteDesa={handleDeleteDesa}
              />
            )}

            {/* View 5: Master Jenis Pelayanan (Admin L1 only) */}
            {activeView === 'master-layanan' && currentUser.role === 'L1' && (
              <KelolaJenisPelayananView
                services={services}
                onAddService={handleAddService}
                onUpdateService={handleUpdateService}
                onDeleteService={handleDeleteService}
              />
            )}

            {/* View 6: Laporan Rekapitulasi */}
            {activeView === 'laporan-rekapitulasi' && (
              <LaporanAnalitikView
                currentUser={currentUser}
                records={records}
                services={services}
                desasList={desasList}
                initialTab="rekapitulasi"
              />
            )}

            {/* View 7: Laporan Grafik */}
            {activeView === 'laporan-grafik' && (
              <LaporanAnalitikView
                currentUser={currentUser}
                records={records}
                services={services}
                desasList={desasList}
                initialTab="grafik"
              />
            )}
          </div>
        </main>
      </div>

      {/* Modal: Input Data Pelayanan Baru */}
      <InputPelayananModal
        isOpen={inputModalOpen}
        onClose={() => setInputModalOpen(false)}
        currentUser={currentUser}
        services={services}
        desasList={desasList}
        existingRecords={records}
        onSaveRecord={handleSaveRecord}
        preselectedServiceId={preselectedServiceId}
      />

      {/* Modal: Detail & Proses Pelayanan */}
      <DetailPelayananModal
        record={selectedRecordForDetail}
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        currentUser={currentUser}
        onUpdateStatus={handleUpdateRecordStatus}
        onDeleteRecord={handleDeleteRecord}
        onPrintReceipt={handleOpenPrint}
      />

      {/* Modal: Cetak Tanda Terima / Resi Pelayanan */}
      <CetakTandaTerimaModal
        record={selectedRecordForPrint}
        isOpen={printModalOpen}
        onClose={() => setPrintModalOpen(false)}
      />

      {/* Modal: Matriks Hak Akses Informasi */}
      <HakAksesMatrixModal
        isOpen={infoMatrixOpen}
        onClose={() => setInfoMatrixOpen(false)}
      />
    </div>
  );
}
