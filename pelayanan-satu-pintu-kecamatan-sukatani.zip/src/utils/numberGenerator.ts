import { getRomanMonth } from '../data/initialData';
import { ServiceDefinition, ServiceRecord } from '../types';

export function generateRegistrationNumber(
  service: ServiceDefinition,
  existingRecords: ServiceRecord[],
  date: Date = new Date()
): string {
  const year = date.getFullYear();
  const monthNum = date.getMonth() + 1;
  const monthStr = monthNum.toString().padStart(2, '0');
  const romanMonth = getRomanMonth(date.getMonth());

  // Count existing records for this service or overall this year
  const recordsThisYear = existingRecords.filter((r) => {
    const rDate = new Date(r.tanggalPengajuan);
    return rDate.getFullYear() === year;
  });

  const nextNumber = recordsThisYear.length + 1;
  const urutPadded = nextNumber.toString().padStart(4, '0');

  let format = service.formatKode;
  if (!format) {
    format = `${service.kode}/{URUT}/${monthStr}/${year}`;
  }

  return format
    .replace('{URUT}', urutPadded)
    .replace('{BULAN}', monthStr)
    .replace('{BULAN_ROMAWI}', romanMonth)
    .replace('{TAHUN}', year.toString());
}

export function formatDateIndonesian(dateString: string): string {
  if (!dateString) return '-';
  try {
    const d = new Date(dateString);
    return d.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  } catch {
    return dateString;
  }
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0,
  }).format(amount);
}
