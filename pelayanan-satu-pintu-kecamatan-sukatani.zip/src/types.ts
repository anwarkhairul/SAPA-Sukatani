export type UserRole = 'L1' | 'L2' | 'L3' | 'L4' | 'L5' | 'L6';

export interface RoleInfo {
  level: UserRole;
  name: string;
  shortName: string;
  description: string;
  seksiCode?: ServiceSeksi;
  allowedSeksi: ServiceSeksi[];
  canManageSystem: boolean;
  canViewAllReports: boolean;
}

export type ServiceSeksi = 'YANLIK' | 'PEMERINTAHAN' | 'EKBANG' | 'PMD' | 'TRANTIB';

export interface UserAccount {
  id: string;
  username: string;
  fullName: string;
  nip: string;
  role: UserRole;
  seksi?: ServiceSeksi;
  email: string;
  jabatan: string;
  isActive: boolean;
  avatarUrl?: string;
}

export interface Desa {
  id: string;
  nama: string;
  kodePos: string;
  namaKepalaDesa: string;
  kontak: string;
  jumlahPenduduk?: number;
}

export interface ServiceDefinition {
  id: string;
  seksi: ServiceSeksi;
  nama: string;
  kode: string;
  formatKode: string; // e.g. "400.7.3.1/{URUT}/{BULAN}/{TAHUN}"
  deskripsi: string;
  iconName: string;
  syaratDokumen: string[];
  customFields?: CustomFieldDefinition[];
}

export interface CustomFieldDefinition {
  key: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'select' | 'textarea';
  required?: boolean;
  options?: string[];
  placeholder?: string;
}

export type ServiceStatus = 'DRAFT' | 'DIVERIFIKASI' | 'DIPROSES' | 'SELESAI' | 'DITOLAK';

export interface CitizenData {
  nik: string;
  namaLengkap: string;
  noKk: string;
  tempatLahir: string;
  tanggalLahir: string;
  jenisKelamin: 'L' | 'P';
  agama: string;
  pekerjaan: string;
  alamat: string;
  desa: string;
  rtRw: string;
  noHp: string;
}

export interface ServiceRecord {
  id: string;
  noRegistrasi: string;
  serviceId: string;
  serviceNama: string;
  seksi: ServiceSeksi;
  tanggalPengajuan: string; // YYYY-MM-DD
  waktuPengajuan: string; // HH:mm
  status: ServiceStatus;
  citizen: CitizenData;
  keperluan: string;
  detailKhusus: Record<string, any>;
  dokumenLengkap: boolean;
  catatanPetugas?: string;
  petugasNama: string;
  petugasNip: string;
  estimasiSelesai?: string;
  tanggalSelesai?: string;
  createdAt: string;
  updatedAt: string;
}
